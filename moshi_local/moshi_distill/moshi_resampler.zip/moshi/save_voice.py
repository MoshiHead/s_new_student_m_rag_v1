"""
make_voice_prompt.py

Encodes a raw voice-prompt audio file (wav/mp3/etc, whatever `sphn.read` can
load) into a cached `.pt` embeddings file that the server can load directly
via `LMGen.load_voice_prompt_embeddings(...)` (fast path, skips re-encoding
audio -> mimi tokens -> transformer embeddings on every request).

It reuses exactly the same objects/flow as `ServerState` in the server
script: load mimi + the LM, build an `LMGen` with
`save_voice_prompt_embeddings=True`, then run the voice prompt through it.

Usage:
    python make_voice_prompt.py --audio /path/to/my_voice.wav

This will produce `/path/to/my_voice.pt` next to the input audio file
(same base name, `.pt` extension) -- that's the convention
`_step_voice_prompt_core` uses internally (`splitext(self.voice_prompt)[0] + ".pt"`),
so keep that in mind if you want a specific output filename: just name/rename
your input audio file accordingly, or pass --rename-output below.
"""

import argparse
import random
import shutil
from pathlib import Path
from typing import Literal, Optional

import numpy as np
import sphn
import torch
from huggingface_hub import hf_hub_download

from .models import loaders
from .models.lm import LMGen

DeviceString = Literal["cuda"] | Literal["cpu"]


def trim_audio(src_path: Path, start: float, duration: float, out_path: Path) -> Path:
    """Cut [start, start + duration] seconds out of src_path and write the
    result to out_path. Sample rate is kept as-is -- load_audio() inside
    LMGen.load_voice_prompt() resamples again to whatever the model expects,
    so there's no need to match it here.
    """
    pcm, sr = sphn.read(str(src_path))  # pcm shape: (C, T)
    total_samples = pcm.shape[-1]
    total_duration = total_samples / sr

    assert start >= 0, "--start must be >= 0"
    start_sample = int(start * sr)
    assert start_sample < total_samples, (
        f"--start {start}s is past the end of the audio "
        f"(source is only {total_duration:.2f}s long)"
    )

    end_sample = int((start + duration) * sr)
    if end_sample > total_samples:
        print(
            f"warning: --start {start}s + --duration {duration}s exceeds the "
            f"source length ({total_duration:.2f}s); clipping to the end."
        )
        end_sample = total_samples

    trimmed = pcm[:, start_sample:end_sample]
    sphn.write_wav(str(out_path), trimmed, sr)
    actual_duration = trimmed.shape[-1] / sr
    print(f"trimmed audio: {start:.2f}s -> {start + actual_duration:.2f}s "
          f"({actual_duration:.2f}s clip) written to {out_path}")
    return out_path


def torch_auto_device(requested: Optional[DeviceString] = None) -> torch.device:
    """Return a torch.device based on the requested string or availability."""
    if requested is not None:
        return torch.device(requested)
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def seed_all(seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.backends.cudnn.deterministic = False
    torch.backends.cudnn.benchmark = False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--audio", type=str, required=True,
                         help="Path to the source voice audio file (wav, mp3, etc).")
    parser.add_argument("--output", type=str, default=None,
                         help="Optional explicit output .pt path. Defaults to "
                              "<audio-file-basename>.pt next to the audio file.")
    parser.add_argument("--device", type=str, default="cuda",
                         help="Device to run encoding on, defaults to 'cuda'.")
    parser.add_argument("--hf-repo", type=str, default=loaders.DEFAULT_REPO,
                         help="HF repo to pull mimi/moshi weights from.")
    parser.add_argument("--mimi-weight", type=str, default=None,
                         help="Local path to a mimi checkpoint (downloads from HF if omitted).")
    parser.add_argument("--moshi-weight", type=str, default=None,
                         help="Local path to a moshi/LM checkpoint (downloads from HF if omitted).")
    parser.add_argument("--seed", type=int, default=42424242)
    parser.add_argument("--start", type=float, default=0.0,
                         help="Start offset (seconds) into the source audio to begin the clip.")
    parser.add_argument("--duration", type=float, default=None,
                         help="Length (seconds) of the clip to use, e.g. 5.0. "
                              "If omitted, the full audio file is used as-is.")
    args = parser.parse_args()

    device = torch_auto_device(args.device)
    seed_all(args.seed)

    audio_path = Path(args.audio).expanduser().resolve()
    assert audio_path.exists(), f"Audio file not found: {audio_path}"
    original_audio_path = audio_path  # used for default output naming below

    if args.duration is not None:
        trimmed_path = audio_path.with_name(audio_path.stem + "_trimmed.wav")
        audio_path = trim_audio(audio_path, args.start, args.duration, trimmed_path)

    print("loading mimi...")
    mimi_weight = args.mimi_weight or hf_hub_download(args.hf_repo, loaders.MIMI_NAME)
    mimi = loaders.get_mimi(mimi_weight, device)

    print("loading moshi (LM)...")
    moshi_weight = args.moshi_weight or hf_hub_download(args.hf_repo, loaders.MOSHI_NAME)
    lm = loaders.get_moshi_lm(moshi_weight, device=device)
    lm.eval()

    with torch.no_grad():
        # save_voice_prompt_embeddings=True is what makes step() cache
        # per-frame embeddings and, once the whole prompt is consumed,
        # write them (plus the resulting cache state) out to a .pt file.
        lm_gen = LMGen(
            lm,
            device=device,
            sample_rate=mimi.sample_rate,
            frame_rate=mimi.frame_rate,
            save_voice_prompt_embeddings=True,
        )

        mimi.streaming_forever(1)
        lm_gen.streaming_forever(1)

        # Point LMGen at the source audio file. It stores this path and
        # `splitext(path)[0] + ".pt"` is where it will write the result.
        lm_gen.load_voice_prompt(str(audio_path))

        print(f"encoding voice prompt from {audio_path} ...")
        # This runs just the voice-prompt portion (encode audio -> mimi
        # tokens -> step through the LM -> save embeddings + cache to .pt).
        # It's the same private helper the server uses inside
        # step_system_prompts(); we call it directly so we don't also
        # burn time stepping through silence/text-prompt padding.
        lm_gen._step_voice_prompt(mimi)

    produced_path = audio_path.with_suffix(".pt")
    assert produced_path.exists(), (
        f"Expected output file was not created at {produced_path}. "
        "Something went wrong in the encoding step."
    )

    # Default output name is based on the ORIGINAL audio filename, not the
    # "*_trimmed.wav" intermediate, so trimming is transparent to the caller.
    default_final_path = original_audio_path.with_suffix(".pt")
    final_path = Path(args.output).expanduser().resolve() if args.output else default_final_path
    if final_path != produced_path:
        shutil.move(str(produced_path), str(final_path))

    if args.duration is not None:
        audio_path.unlink(missing_ok=True)  # clean up the intermediate trimmed wav

    print(f"done. voice prompt embeddings saved to: {final_path}")
    print(
        "To use it at inference time, either place it in your "
        "--voice-prompt-dir and request it by filename (ending in .pt), "
        "which triggers `lm_gen.load_voice_prompt_embeddings(...)` on the "
        "server automatically."
    )


if __name__ == "__main__":
    main()