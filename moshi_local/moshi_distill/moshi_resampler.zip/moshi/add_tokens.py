"""
One-time offline script: appends new CONTROL-type special tokens to an
existing sentencepiece .model file. CONTROL pieces are never produced by
normal text segmentation/encode of arbitrary strings — only reachable via
explicit id lookup (tokenizer.piece_to_id("<lookup>")). This matters:
training code never calls tokenizer.encode("<lookup>") — it looks up the
id directly — so CONTROL is the right type, not USER_DEFINED (which
participates in ordinary string matching and could otherwise collide with
someone's transcript literally containing that substring).

IMPORTANT: run this against the ORIGINAL base tokenizer (the one with no
prior special-token additions), not a .model file that already had other
tokens appended by a previous run of this script. Running against an
already-modified file is how you end up with sparse/non-contiguous ids
(e.g. <lookup> landing at 32002 instead of 32000) if a later training run
only wants a subset of what was previously added — add_special_tokens_and_resize
assumes new_tokens starts exactly at old_text_card and will hard-fail
otherwise. One base file, one clean append, one token: <lookup>.

Run once, produces a new .model file. Point --tokenizer at the new file.
"""
import argparse
import sentencepiece as spm
from sentencepiece import sentencepiece_model_pb2 as spm_pb2

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in-model", required=True,
        help="path to the ORIGINAL base tokenizer .model — must NOT already "
             "contain other appended special tokens from a prior run of this "
             "script, or ids will be non-contiguous with what training expects.")
    ap.add_argument("--out-model", required=True, help="path to write the new .model")
    ap.add_argument("--tokens", nargs="+", default=["<lookup>"],
        help="Tokens to append as CONTROL pieces. Default is just <lookup> — "
             "the single behavioral-decision token the current training "
             "pipeline actually trains a gradient for. Do not add "
             "<ref_start>/<ref_end> unless the interleaver splices them "
             "back in as real bracket tokens (it currently doesn't — ref-slot "
             "frames are position-only placeholders, no bracket tokens).")
    args = ap.parse_args()

    m = spm_pb2.ModelProto()
    with open(args.in_model, "rb") as f:
        m.ParseFromString(f.read())
    existing = {p.piece for p in m.pieces}
    before_size = len(m.pieces)

    for tok in args.tokens:
        if tok in existing:
            raise ValueError(
                f"{tok!r} already present in vocab (id would collide). This "
                f"usually means --in-model already has special tokens appended "
                f"from a previous run — pass the ORIGINAL base tokenizer instead, "
                f"or pick a different token string if this really is intentional."
            )
        new_piece = spm_pb2.ModelProto.SentencePiece()
        new_piece.piece = tok
        new_piece.score = 0.0
        new_piece.type = spm_pb2.ModelProto.SentencePiece.CONTROL
        m.pieces.append(new_piece)

    with open(args.out_model, "wb") as f:
        f.write(m.SerializeToString())

    # verify: reload with the real spm library, confirm contiguous ids at the end
    sp = spm.SentencePieceProcessor(model_file=args.out_model)
    print(f"before: {before_size} pieces, after: {sp.GetPieceSize()} pieces")
    for i, tok in enumerate(args.tokens):
        tid = sp.piece_to_id(tok)
        expected = before_size + i
        status = "OK" if tid == expected else "MISMATCH"
        print(f"  {tok!r} -> id {tid} (expected {expected}) [{status}]")
        assert tid == expected, (
            "Ids did not land contiguously at the end — do not proceed to "
            "training with this model file, add_special_tokens_and_resize "
            "will assert on this."
        )

if __name__ == "__main__":
    main()