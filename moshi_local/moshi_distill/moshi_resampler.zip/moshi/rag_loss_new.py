"""
Extended loss computation for RAG fine-tuning — literal <ref> text approach
and Perceiver-resampler approach both use this module identically.

Builds on the base text/audio CE by adding:
  - per-segment text weights (lead / ref-token-frame / filler / ref-context / body)
  - NaN-safe handling of undelayed logits (masked positions come back as
    real NaN from _undelay_sequence's fill_value, not zero — must be
    sanitized BEFORE cross_entropy, not after, or backward can propagate
    NaN gradients even though the forward-masked value looks fine)

The contrastive and reliance objectives are assembled by train_latent.py and
must compare references through the same additive streaming-sum pathway used
by the actual forward pass.
"""

from __future__ import annotations
from dataclasses import dataclass
import random
import torch
import torch.nn.functional as F
from .models.lm import AUDIO_TOKENS_PER_STREAM


from dataclasses import dataclass, field

def make_audio_synthetic_mask(B, T, seg_metas, device):
    keep = torch.ones((B, T), dtype=torch.float32, device=device)
    for meta in seg_metas:
        b = meta.batch_idx
        for span in meta.turns:
            if span.kind not in ("ref", "ref_slot"):
                continue
            s, e = max(0, span.start_frame), min(T, span.end_frame)
            if s < e:
                keep[b, s:e] = 0.0
    return keep
    

@dataclass
class TurnSpan:
    kind: str          # "regular" | "lead" | "lookup" | "filler" | "ref" | "body"
    start_frame: int
    end_frame: int      # exclusive


@dataclass
class SegmentMeta:
    turns: list[TurnSpan] = field(default_factory=list)
    n_ref_tokens: int = 0
    n_lookup_tokens: int = 0
    batch_idx: int = 0

    def spans_of(self, kind: str) -> list[TurnSpan]:
        return [t for t in self.turns if t.kind == kind]


def make_segment_weight_tensor(
    B: int, T: int, seg_metas: list[SegmentMeta],
    device: torch.device,
    ref_weight: float = 5.0,
    lookup_weight: float = 10.0,     # ← raised: this frame now carries BOTH
                                       #   "model should emit this token" AND
                                       #   "this is where grounding begins"
    lead_weight: float = 1.0,
    filler_weight: float = 1.0,
    ref_context_weight: float = 1.0,
    body_weight: float = 2.0,
    no_rag_weight: float = 1.0,
) -> torch.Tensor:
    weights = torch.full((B, T), no_rag_weight, dtype=torch.float32, device=device)
    kind_weight = {
        "regular": no_rag_weight,
        "lead": lead_weight,
        "lookup": lookup_weight,
        "filler": filler_weight,
        "ref": ref_weight,
        "ref_slot": ref_context_weight,
        "body": body_weight,
        "system": 0.0,       # forced at inference, never a generation target
    }
    for meta in seg_metas:
        b = meta.batch_idx
        for span in meta.turns:
            s, e = max(0, span.start_frame), min(T, span.end_frame)
            if s >= e:
                continue
            weights[b, s:e] = kind_weight.get(span.kind, no_rag_weight)
    return weights


# ---------------------------------------------------------------------------
# Text loss with segment weights
# ---------------------------------------------------------------------------

def compute_text_loss_rag(
    text_logits: torch.Tensor,   # [B, 1, T, text_card] — contains real NaN at masked positions
    text_codes:  torch.Tensor,   # [B, 1, T]
    text_mask:   torch.Tensor,   # [B, 1, T]
    seg_weights: torch.Tensor,   # [B, T]
    text_padding_weight: float = 1.0,
    text_padding_ids: set[int] | None = None,
) -> torch.Tensor:
    """
    Extended text CE with per-frame segment weights.

    IMPORTANT: text_logits comes from _undelay_sequence(..., fill_value=NaN).
    Masked-out positions contain ACTUAL NaN, not zero. NaN must be
    sanitized BEFORE cross_entropy — NaN * 0 == NaN in IEEE754, so
    multiplying by a zero weight AFTER the fact does not clean it, and
    can leak NaN gradients into the backward graph even though the
    forward value looks correct via torch.where.
    """
    mask_2d = text_mask[:, 0, :].float()
    weights = seg_weights * mask_2d   # [B, T]

    if text_padding_ids is not None:
        codes_2d = text_codes[:, 0, :]
        for pad_id in text_padding_ids:
            weights[codes_2d == pad_id] *= text_padding_weight

    logits_flat = text_logits[:, 0].reshape(-1, text_logits.size(-1)).float()
    logits_flat = torch.nan_to_num(logits_flat, nan=0.0, posinf=0.0, neginf=0.0)  # sanitize BEFORE CE

    target_flat = text_codes[:, 0].reshape(-1)
    weights_flat = weights.reshape(-1)

    target_safe = torch.where(
        weights_flat > 0, target_flat, torch.zeros_like(target_flat),
    )

    loss_per_tok = F.cross_entropy(logits_flat, target_safe, reduction="none")
    loss_per_tok = loss_per_tok * weights_flat   # safe now: no NaN operand anywhere
    return loss_per_tok.sum() / weights_flat.sum().clamp(min=1e-8)


def compute_lookup_ce(text_logits: torch.Tensor, codes: torch.Tensor, seg_metas,
                      weight: float = 1.0) -> torch.Tensor:
    """Undiluted CE on the <lookup> decision frame(s).

    Folding the lookup frame into the weighted-mean text loss dilutes a rare
    single-frame target to near-zero, so the trigger needs its own term. The old
    rag_head played this role; with it dropped, this is the signal that teaches
    the model to actually emit <lookup>."""
    logits = text_logits[:, 0]                                   # [B, T, V]
    T = logits.shape[1]
    terms = []
    for m in seg_metas:
        if m is None:
            continue
        for span in m.spans_of("lookup"):
            f = span.start_frame
            if 0 <= f < T:
                lg = torch.nan_to_num(logits[m.batch_idx, f].float(),
                                      nan=0.0, posinf=0.0, neginf=0.0).unsqueeze(0)
                tgt = codes[m.batch_idx, 0, f].unsqueeze(0)
                terms.append(F.cross_entropy(lg, tgt))
    if not terms:
        return torch.tensor(0.0, device=logits.device)
    return weight * torch.stack(terms).mean()


# ---------------------------------------------------------------------------
# Lookup Token Loss
# ---------------------------------------------------------------------------
def compute_rag_trigger_loss(rag_logits: torch.Tensor, seg_metas, pos_weight: float = 20.0) -> torch.Tensor:
    """Binary decision, dedicated head — not competing in the ~32k-way text
    vocab softmax. pos_weight compensates for lookup frames being rare
    without diluting the signal the way folding it into a full-sequence
    weighted mean did."""
    B, T, _ = rag_logits.shape
    targets = torch.zeros(B, T, device=rag_logits.device)
    for meta in seg_metas:
        for span in meta.spans_of("lookup"):
            if span.start_frame < T:
                targets[meta.batch_idx, span.start_frame] = 1.0
    logits_flat = rag_logits.squeeze(-1).reshape(-1)
    targets_flat = targets.reshape(-1)
    return F.binary_cross_entropy_with_logits(
        logits_flat, targets_flat,
        pos_weight=torch.tensor(pos_weight, device=rag_logits.device),
    )
    
# ---------------------------------------------------------------------------
# Audio loss
# ---------------------------------------------------------------------------

def compute_audio_loss(logits, audio_codes, mask, first_codebook_weight_multiplier=1.0,
                        synthetic_keep=None, num_agent_codebooks=None):
    target = torch.where(mask, audio_codes, torch.zeros_like(audio_codes))
    weights = mask.float()

    if num_agent_codebooks is not None:

        agent_mask = torch.zeros(weights.shape[1], device=weights.device, dtype=weights.dtype)
        agent_mask[:num_agent_codebooks] = 1.0
        weights = weights * agent_mask[None, :, None]

    weights[:, 0] *= first_codebook_weight_multiplier
    if synthetic_keep is not None:
        weights = weights * synthetic_keep[:, None, :]

    logits_flat = logits.reshape(-1, logits.size(-1)).float()
    logits_flat = torch.nan_to_num(logits_flat, nan=0.0, posinf=0.0, neginf=0.0)
    target_flat = target.reshape(-1)
    weights_flat = weights.reshape(-1)
    loss_per_tok = F.cross_entropy(logits_flat, target_flat, reduction="none")
    loss_per_tok = loss_per_tok * weights_flat
    return loss_per_tok.sum() / weights_flat.sum().clamp(min=1e-8)


# ---------------------------------------------------------------------------
# Combined RAG loss — 2-tuple return, matches both train_rag.py and
# train_rag_resampler.py's `text_loss, audio_loss = compute_rag_losses(...)`
# ---------------------------------------------------------------------------

def compute_rag_losses(
    model,
    output,
    codes: torch.Tensor,
    seg_metas: list[SegmentMeta],
    args,
) -> tuple[torch.Tensor, torch.Tensor]:
    B, K, T = codes.shape
    device = codes.device
    text_padding_ids = {model.text_padding_token_id, model.end_of_text_padding_id}

    seg_weights = make_segment_weight_tensor(
        B=B, T=T, seg_metas=seg_metas, device=device,
        ref_weight=getattr(args, "ref_token_weight", 5.0),
        lookup_weight=getattr(args, "lookup_loss_weight", 5.0),
        lead_weight=getattr(args, "lead_weight", 1.0),
        filler_weight=getattr(args, "filler_weight", 1.0),
        ref_context_weight=getattr(args, "ref_context_weight", 1.0),
        body_weight=getattr(args, "body_weight", 2.0),
        no_rag_weight=getattr(args, "no_rag_weight", 1.0),
    )

    text_loss = compute_text_loss_rag(
        text_logits=output.text_logits,
        text_codes=codes[:, :model.audio_offset],
        text_mask=output.text_mask,
        seg_weights=seg_weights,
        text_padding_weight=getattr(args, "text_padding_weight", 1.0),
        text_padding_ids=text_padding_ids,
    )

    synthetic_keep = make_audio_synthetic_mask(B=B, T=T, seg_metas=seg_metas, device=device)
    audio_loss = compute_audio_loss(
        logits=output.logits,
        audio_codes=codes[:, model.audio_offset : model.audio_offset + model.dep_q],
        mask=output.mask,
        first_codebook_weight_multiplier=getattr(args, "first_codebook_weight_multiplier", 1.0),
        synthetic_keep=synthetic_keep,
        num_agent_codebooks=getattr(args, "num_agent_codebooks", AUDIO_TOKENS_PER_STREAM),
    )
    return text_loss, audio_loss
