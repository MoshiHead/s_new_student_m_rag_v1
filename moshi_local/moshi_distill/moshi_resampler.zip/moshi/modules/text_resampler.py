"""Reference-text resampler using the LM's OWN tokenizer and frozen text_emb
— no separate pretrained encoder. Reasoning + compression happen entirely in
the LM's native embedding space, so context_proj only has to learn a
residual mapping within a space the model already understands, not a
translation from an unrelated embedding space (e.g. MiniLM) into it."""

from __future__ import annotations

import torch
from torch import nn

from transformers import AutoModel, AutoTokenizer





class TextResampler(nn.Module):
    def __init__(self, text_emb, context_dim, d_internal=1024, n_ref_slots=32,
                 n_layers=4, n_heads=8, max_ref_len=512, device=None, dtype=None,
                 soft_token: bool = False, soft_tau: float = 1.0, hard_token: bool = False,
                 norm_out: bool = True):
        super().__init__()
        self.text_emb = text_emb
        self.context_dim = context_dim
        self.n_ref_slots = n_ref_slots   # maximum active slot count
        self.soft_token = bool(soft_token)
        self.soft_tau = float(soft_tau)
        self.hard_token = bool(hard_token)
        self.in_proj = nn.Linear(text_emb.embedding_dim, d_internal, device=device, dtype=dtype)

        pe = torch.zeros(max_ref_len, d_internal, device=device, dtype=dtype)
        position = torch.arange(0, max_ref_len, dtype=torch.float, device=device).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_internal, 2, dtype=torch.float, device=device)
                             * (-torch.log(torch.tensor(10000.0)) / d_internal))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pos_encoding", pe.unsqueeze(0), persistent=False)

        enc_layer = nn.TransformerEncoderLayer(
            d_internal, n_heads, dim_feedforward=d_internal * 4, batch_first=True,
            device=device, dtype=dtype,
        )
        self.reason = nn.TransformerEncoder(enc_layer, num_layers=n_layers, enable_nested_tensor=False)

     
        self.slot_queries = nn.Parameter(torch.randn(1, n_ref_slots, d_internal, device=device, dtype=dtype) * 0.02)
        self.slot_attn = nn.MultiheadAttention(d_internal, n_heads, batch_first=True, device=device, dtype=dtype)

        self.out_proj = nn.Linear(d_internal, context_dim, device=device, dtype=dtype)
        # The base model's embeddings are RAW (ScaledEmbedding with norm off), and
        # the frame input is a SUM of them. LayerNorm here would impose a shape the
        # base never sees; make it optional so you can match that convention.
        self.out_norm = nn.LayerNorm(context_dim, device=device, dtype=dtype) if norm_out else None

        # Auxiliary content head: predicts, per slot, the reference token
        # distribution. Trained with the chunked reconstruction loss so the K
        # slots stay content-bearing even when the emitted vectors are NOT tied
        # to the token table (soft_token=False).
        self.vocab_proj = nn.Linear(d_internal, text_emb.num_embeddings, device=device, dtype=dtype)
        # Larger-than-default init so the initial distributions are non-uniform
        # (a near-uniform softmax would collapse the soft-token output to the
        # mean embedding ~0).
        nn.init.normal_(self.vocab_proj.weight, std=0.5)
        nn.init.zeros_(self.vocab_proj.bias)
        # Learnable output scale: lets the model set the injection magnitude.
        # Regular turns have no injection, so a non-zero init is safe.
        self.output_scale = nn.Parameter(torch.ones(1, device=device, dtype=torch.float32))
        # Gate for the persistent per-step body grounding (pooled summary added
        # to every body frame). Only body frames receive it, so regular turns are
        # unaffected regardless of this init; start at a mild non-zero value so
        # the channel actually engages (a 0 init is a dead gate here).
        self.body_gate = nn.Parameter(torch.full((1,), 0.2, device=device, dtype=torch.float32))

    def encode_slots(self, ref_input_ids, ref_attn_mask, return_logits: bool = False):
        """Returns up to n_ref_slots latents at context_dim width.
        Callers select the active prefix for the reference length."""
        with torch.no_grad():
            x = self.text_emb(ref_input_ids)
        # text_emb may be bf16 (frozen backbone) while the resampler runs in
        # fp32 for optimizer precision; match in_proj's dtype.
        x = self.in_proj(x.to(self.in_proj.weight.dtype))
        L = x.shape[1]
        x = x + self.pos_encoding[:, :L, :]
        key_padding_mask = ~ref_attn_mask.bool()
        x = self.reason(x, src_key_padding_mask=key_padding_mask)   # [B, L, d_internal]

        B = x.shape[0]
        queries = self.slot_queries.expand(B, -1, -1)               # [B, n_ref_slots, d_internal]
        slots, _ = self.slot_attn(queries, x, x, key_padding_mask=key_padding_mask)  # [B, n_ref_slots, d_internal]

        logits = self.vocab_proj(slots)                              # [B, K, V] (aux content head)
        if self.soft_token:
            probs = torch.softmax(logits.float() / self.soft_tau, dim=-1)
            if self.hard_token:
                # Straight-through hard tokens: the LM sees real (discrete)
                # token embeddings and the adapter still gets gradients.
                hard = torch.zeros_like(probs)
                hard.scatter_(-1, probs.argmax(dim=-1, keepdim=True), 1.0)
                st = hard + probs - probs.detach()
                lifted = st @ self.text_emb.weight.to(st.dtype)
            else:
                lifted = probs @ self.text_emb.weight.to(probs.dtype)  # [B, K, dim]
        else:
            # Expressive in-space vectors (not restricted to the token convex
            # hull). Optionally LayerNorm'd; raw (norm_out=False) matches the
            # base model's un-normalized embedding convention.
            lifted = self.out_proj(slots)
            if self.out_norm is not None:
                lifted = self.out_norm(lifted)
        lifted = lifted * self.output_scale.to(lifted.dtype)
        valid_mask = torch.ones(B, self.n_ref_slots, dtype=torch.bool, device=x.device)
        if return_logits:
            return lifted, valid_mask, logits
        return lifted, valid_mask

    def reconstruction_loss(self, logits, ref_input_ids, ref_attn_mask,
                            active_slots: torch.Tensor | None = None):
        """Order-aware chunked reconstruction: the reference is split into K
        contiguous chunks and frame k must cover chunk k's token distribution.
        Unlike a global bag-of-tokens this forces the K frames to be *distinct*
        and position-specific, which is what makes correct vs wrong references
        actually differ downstream."""
        B, K, V = logits.shape
        logp = torch.log_softmax(logits.float(), dim=-1)             # [B, K, V]
        L = ref_input_ids.shape[1]
        ids = ref_input_ids.clamp(min=0, max=V - 1)
        mask = ref_attn_mask.float()
        # Chunk by the ACTUAL token count of each sample, not the padded length
        # (refs are padded to max_ref_source_tokens, which previously dropped all
        # real tokens into the first few chunks and left most slots unsupervised).
        lens = mask.sum(dim=1, keepdim=True).clamp(min=1.0)          # [B, 1]
        if active_slots is None:
            active_slots = torch.full(
                (B,), K, device=logits.device, dtype=torch.long)
        active_slots = active_slots.to(device=logits.device, dtype=torch.long).clamp(0, K)
        pos = torch.arange(L, device=ids.device).view(1, L).float()   # [1, L]
        chunk = (pos * active_slots[:, None].clamp_min(1) / lens).long().clamp(max=K - 1)
        counts = torch.zeros(B, K, V, device=logits.device, dtype=torch.float32)
        flat = counts.view(B, K * V)
        add_idx = chunk * V + ids                                     # [B, L]
        flat.scatter_add_(1, add_idx, mask)
        counts = counts / counts.sum(dim=-1, keepdim=True).clamp(min=1.0)
        loss = -(counts * logp).sum(dim=-1)                           # [B, K]
        slot_ids = torch.arange(K, device=logits.device)[None, :]
        valid_k = (counts.sum(dim=-1) > 0) & (slot_ids < active_slots[:, None])
        return (loss * valid_k).sum() / valid_k.sum().clamp(min=1)


    def encode(self, ref_input_ids, ref_attn_mask):
        """Pooled single vector — average the fixed slots. Still useful
        if any call site wants one vector (e.g. the trigger/contrastive
        comparisons), but no longer the primary consumption path."""
        latents, valid_mask = self.encode_slots(ref_input_ids, ref_attn_mask)
        return latents, latents.mean(dim=1)

    def pool(self, latents, valid_mask=None):
        if valid_mask is None:
            return latents.mean(dim=1)
        weights = valid_mask.to(latents.dtype).unsqueeze(-1)
        return (latents * weights).sum(dim=1) / weights.sum(dim=1).clamp_min(1.0)

    def forward(
        self, ref_input_ids: torch.Tensor, ref_attn_mask: torch.Tensor
    ) -> torch.Tensor:
        """Pooled vector only — kept for older call sites."""
        _latents, pooled = self.encode(ref_input_ids, ref_attn_mask)
        return pooled

    @torch.no_grad()
    def encode_texts(
        self,
        texts: list[str],
        tokenizer: AutoTokenizer,
        max_length: int = 300,
        device=None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Offline / async path: tokenize strings, return (latents, pooled)."""
        if not texts:
            raise ValueError("encode_texts requires at least one string")
        enc = tokenizer(
            texts,
            padding="max_length",
            truncation=True,
            max_length=max_length,
            return_tensors="pt",
        )
        device = device or next(self.parameters()).device
        return self.encode(
            enc["input_ids"].to(device),
            enc["attention_mask"].to(device).bool(),
        )


# Back-compat alias used by train_latent.py
RefResampler = TextResampler
