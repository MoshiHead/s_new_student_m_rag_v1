"""Additive, text-only context injection.

Replaces the FiLM-style gated residual + per-layer AdaLN. The context vector
is projected once and added directly to the text embedding component of the
current frame, before it's summed with the audio embedding. Nothing touches
transformer hidden states layer-by-layer anymore, so there's no mechanism
left that can rescale the fused audio+text stream globally.
"""
from __future__ import annotations
import torch
from torch import nn


def apply_text_context_sum(
    text_emb: torch.Tensor,      # [B, S, D]
    audio_sum: torch.Tensor,     # [B, S, D] — untouched
    ctx_seq: torch.Tensor,       # [B, S, D] — ALREADY time-aligned: ctx_seq[b, s] is the
                                  # vector active at frame s (last-latent-held past the end
                                  # of the compressed sequence), zero where inactive
    proj: nn.Module,             # plain Linear, zero-init
    active: torch.Tensor,        # [B, S] or [B, S, 1]
) -> torch.Tensor:
    delta = proj(ctx_seq)                                # [B, S, D], per-frame now
    if active.dim() == 2:
        active = active.unsqueeze(-1)
    gain = active.to(dtype=text_emb.dtype)
    text_out = text_emb + delta * gain
    return audio_sum + text_out


def frame_active_mask(
    batch_size: int,
    seq_len: int,
    body_starts: torch.Tensor | None,
    body_ends: torch.Tensor | None,
    device: torch.device,
) -> torch.Tensor:
    """[B, S, 1] mask: 1 on frames in [body_start, body_end). Unchanged."""
    if body_starts is None:
        return torch.ones(batch_size, seq_len, 1, device=device)
    frame_idx = torch.arange(seq_len, device=device).view(1, seq_len)
    starts = body_starts.view(batch_size, 1)
    upper = (
        torch.full_like(starts, seq_len)
        if body_ends is None
        else torch.where(body_ends.view(batch_size, 1) >= 0, body_ends.view(batch_size, 1), seq_len)
    )
    mask = (frame_idx >= starts) & (frame_idx < upper) & (starts >= 0)
    return mask.unsqueeze(-1).to(dtype=torch.float32)