"""Gated cross-attention grounding adapter.

Injected at the *text output* of the main transformer only:

    text_hidden = transformer_out + adapter(transformer_out, memory, active)
    text_logits = text_linear(text_hidden)

`transformer_out` is returned unchanged to the depformer, so the audio pathway
is untouched. The memory is a fixed-size [B, K, dim] bank of resampler latents;
the per-frame `active` mask (from the context-commit point through the body)
keeps regular turns exactly as the pretrained model.

Each block's output projection is zero-initialised and a `tanh(gate)` scalar is
initialised at 0, so at step 0 the adapter is an exact no-op — the model keeps
its original behaviour until grounding proves useful.
"""
from __future__ import annotations

import torch
from torch import nn


class GatedCrossAttention(nn.Module):
    def __init__(self, dim: int, n_heads: int, device=None, dtype=torch.float32):
        super().__init__()
        self.norm = nn.LayerNorm(dim, device=device, dtype=dtype)
        self.attn = nn.MultiheadAttention(dim, n_heads, batch_first=True,
                                          device=device, dtype=dtype)
        self.out = nn.Linear(dim, dim, device=device, dtype=dtype)
        self.gate = nn.Parameter(torch.zeros(1, device=device, dtype=dtype))
        nn.init.zeros_(self.out.weight)
        nn.init.zeros_(self.out.bias)

    def forward(self, x, memory, active):
        h, _ = self.attn(self.norm(x), memory, memory, need_weights=False)
        d = self.out(h) * torch.tanh(self.gate)
        if active is not None:
            d = d * active.to(d.dtype)
        return d


class GroundingAdapter(nn.Module):
    def __init__(self, dim: int, n_heads: int = 8, n_layers: int = 2,
                 device=None, dtype=torch.float32):
        super().__init__()
        self.dim = dim
        self.n_layers = n_layers
        self.layers = nn.ModuleList([
            GatedCrossAttention(dim, n_heads, device=device, dtype=dtype)
            for _ in range(n_layers)
        ])

    def forward(self, x: torch.Tensor, memory: torch.Tensor,
                active: torch.Tensor | None = None) -> torch.Tensor:
        """Returns the residual delta (same dtype as x). memory: [B, K, dim] or
        [K, dim]. active: [B, T] or [B, T, 1] (1 where grounding may apply).

        Runs in the dtype of its own parameters (kept fp32 by the loaders /
        trainer), casting the activations at the boundary so it never mismatches
        the bf16 backbone."""
        if memory is None:
            return torch.zeros_like(x)
        p = next(self.parameters())
        xd = x.to(p.dtype)
        md = memory.to(p.dtype)
        if md.dim() == 2:
            md = md.unsqueeze(0).expand(xd.shape[0], -1, -1)
        if active is not None and active.dim() == 2:
            active = active.unsqueeze(-1)
        delta = torch.zeros_like(xd)
        for layer in self.layers:
            delta = delta + layer(xd + delta, md, active)
        return delta.to(x.dtype)
