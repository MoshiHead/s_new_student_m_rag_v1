"""
train_rag.py
============
Fine-tuning script for RAG-aware Moshi LM.
Usage
-----
    python train_rag.py \
        --train-data   data/train.jsonl \
        --eval-data    data/eval.jsonl \
        --moshi-weight /path/to/moshi.safetensors \
        --mimi-weight  /path/to/mimi.safetensors \
        --tokenizer    /path/to/tokenizer.model \
        --out-dir      checkpoints/rag_lora \
        --device       cuda

    # Resume from checkpoint
    python train_rag.py ... --resume checkpoints/rag_lora/step_1000

Hyper-parameters (matching provided config)
--------------------------------------------
    --lora-rank 128  --lora-scaling 2.0
    --lr 2e-6  --weight-decay 0.1
    --batch-size 16  --max-steps 2000
    --duration-sec 100
    --first-codebook-weight 100.0  --text-padding-weight 0.5
    --ref-token-weight 5.0  --body-weight 2.0  --filler-weight 0.5
    --contrastive-weight 0.3  --contrastive-margin 0.3
"""

from __future__ import annotations

import argparse
import json
import logging
import os
# os.environ["CUDA_LAUNCH_BLOCKING"] = "1" 
import random
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional
from functools import partial

import numpy as np
import sentencepiece
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.optim.lr_scheduler import LinearLR, SequentialLR

from huggingface_hub import hf_hub_download

# Project imports — same package as offline inference
from .models import loaders
from .models.lm import LMModel
from .models.lm import LMModel, ScaledEmbedding

# Our pipeline modules
from .rag_loss_new import compute_rag_losses, compute_lookup_ce, SegmentMeta, make_segment_weight_tensor
from .dataset import build_data_loader
from .interleaver import (
    InterleavedTokenizer, Interleaver, Batch, compute_ref_slot_count,
)
from transformers import AutoTokenizer

from .modules.text_resampler import RefResampler          # NEW — replaces local class below



logger = logging.getLogger(__name__)

def _sp_encode_batch(sp_tokenizer, texts, max_length, pad_id, device):
    ids_list = [sp_tokenizer.encode(t)[:max_length] for t in texts]
    B = len(ids_list)
    input_ids = torch.full((B, max_length), pad_id, dtype=torch.long, device=device)
    attn_mask = torch.zeros((B, max_length), dtype=torch.bool, device=device)
    for i, ids in enumerate(ids_list):
        input_ids[i, :len(ids)] = torch.tensor(ids, device=device)
        attn_mask[i, :len(ids)] = True
    return input_ids, attn_mask
    
def apply_lora_to_streaming_attention(lm_base, rank=32, alpha=64.0, include_ffn=True,
                                      include_depformer=True):
    """Freezes lm_base entirely, then attaches LoRA to:
      - in_proj_weight (bare Parameter, parametrized directly) and
        out_proj.weight (real Linear, parametrized the same way) on every
        StreamingMultiheadAttention — attention coverage, unchanged from
        before.
      - NEW: the FFN. This architecture uses gating="silu" (per _lm_kwargs),
        so StreamingTransformerLayer.linear1/linear2 are None and the FFN
        actually lives inside self.gating, a single module (weights_per_step
        is unset, so it's not a ModuleList here) — NOT a plain nn.Linear
        itself, so we recurse into its children to find the real Linears.
        Previously FFN was entirely frozen, leaving LoRA's only lever for
        content/audio adaptation as attention patterns.
    Covers lm.transformer and, unless include_depformer is False, lm.depformer.
    Set include_depformer=False to keep the audio pathway frozen. Returns new
    trainable params for the optimizer.
    """
    from torch.nn.utils.parametrize import register_parametrization
    from .modules.transformer import StreamingMultiheadAttention, StreamingTransformerLayer, LoRAWeightDelta

    for p in lm_base.parameters():
        p.requires_grad_(False)

    depformer_ids = ({id(m) for m in lm_base.depformer.modules()}
                     if (not include_depformer and getattr(lm_base, "depformer", None) is not None)
                     else set())

    n_attn, n_ffn = 0, 0
    for module in lm_base.modules():
        if id(module) in depformer_ids:
            continue
        if isinstance(module, StreamingMultiheadAttention):
            module.in_proj_weight.requires_grad_(False)
            register_parametrization(
                module, "in_proj_weight",
                LoRAWeightDelta(module.in_proj_weight.shape, rank, alpha,
                                 device=module.in_proj_weight.device, dtype=module.in_proj_weight.dtype))
            module.out_proj.weight.requires_grad_(False)
            register_parametrization(
                module.out_proj, "weight",
                LoRAWeightDelta(module.out_proj.weight.shape, rank, alpha,
                                 device=module.out_proj.weight.device, dtype=module.out_proj.weight.dtype))
            n_attn += 1

        elif include_ffn and isinstance(module, StreamingTransformerLayer):
            # linear1/linear2 present only when gating="none" — our config
            # uses gating="silu", so both are None and this branch never
            # fires for them; kept for completeness / other configs.
            for lin in (module.linear1, module.linear2):
                if lin is None:
                    continue
                lin.weight.requires_grad_(False)
                register_parametrization(
                    lin, "weight",
                    LoRAWeightDelta(lin.weight.shape, rank, alpha,
                                     device=lin.weight.device, dtype=lin.weight.dtype))
                n_ffn += 1

           
            if module.gating is not None:
                gating_modules = module.gating if isinstance(module.gating, torch.nn.ModuleList) else [module.gating]
                for gm in gating_modules:
                    for name, child in gm.named_modules():
                        if isinstance(child, torch.nn.Linear):
                            child.weight.requires_grad_(False)
                            register_parametrization(
                                child, "weight",
                                LoRAWeightDelta(child.weight.shape, rank, alpha,
                                                 device=child.weight.device, dtype=child.weight.dtype))
                            n_ffn += 1

    lora_params = []
    for m in lm_base.modules():
        if hasattr(m, "parametrizations"):
            for pname in m.parametrizations:
                for p in m.parametrizations[pname][0].parameters():
                    lora_params.append(p)

    logger.info(f"LoRA attached to {n_attn} attention modules + {n_ffn} FFN linears "
                f"(gating-based) — {sum(p.numel() for p in lora_params):,} trainable params")
    return lora_params

def build_ref_memory_batch(seg_metas, ref_texts, sp_tokenizer, pad_id, resampler, device, args):
    """Returns (memory [B,K,dim], recon scalar, ref_ids [B,L], ref_lens [B],
    body_add [B,dim]).

    - `memory`: the K compressed context vectors (detail frames).
    - `body_add`: the pooled summary gated by `body_gate`, added to every body
      frame (persistent grounding). Zero for non-live samples.
    - `ref_ids`/`ref_lens`: raw reference tokens, for the copy-forcing loss."""
    B = len(seg_metas)
    dim = resampler.context_dim
    n_slots = args.n_ref_slots
    L = args.max_ref_source_tokens
    ref_ids = torch.zeros(B, L, device=device, dtype=torch.long)
    ref_lens = torch.zeros(B, device=device, dtype=torch.long)
    recon = torch.zeros((), device=device)

    live = []
    for i, (m, t) in enumerate(zip(seg_metas, ref_texts)):
        if m is None or not t or m.body_start < 0:
            continue
        token_count = len(sp_tokenizer.encode(t)[:L])
        n_active = m.n_ref_slots or compute_ref_slot_count(
            token_count, n_slots, args.ref_tokens_per_slot, args.min_ref_slots)
        live.append((i, t, n_active))
    if not live:
        memory = torch.zeros(B, n_slots, dim, device=device, dtype=torch.float32)
        body_add = torch.zeros(B, dim, device=device, dtype=torch.float32)
        return memory, recon, ref_ids, ref_lens, body_add

    input_ids, attn_mask = _sp_encode_batch(
        sp_tokenizer, [t for _, t, _ in live], L, pad_id, device
    )
    lifted, _valid, logits = resampler.encode_slots(input_ids, attn_mask, return_logits=True)
    # Do not fill a preallocated tensor with indexed assignment here: that
    # severs the autograd graph from the resampler outputs. Stack live tensors
    # with zero rows so LM text/reliance gradients reach the slot encoder.
    memory_rows = [torch.zeros(n_slots, dim, device=device, dtype=torch.float32) for _ in range(B)]
    active_slots = torch.zeros(B, device=device, dtype=torch.long)
    for j, (i, _t, n_active) in enumerate(live):
        memory_rows[i][:n_active] = lifted[j, :n_active].float()
        active_slots[i] = n_active
        n = int(attn_mask[j].sum().item())
        ref_ids[i, :n] = input_ids[j, :n]
        ref_lens[i] = n
    memory = torch.stack(memory_rows, dim=0)
    if logits is not None:
        recon = resampler.reconstruction_loss(
            logits, input_ids, attn_mask, active_slots=active_slots[[i for i, _, _ in live]]
        )
    # Persistent grounding: pooled summary, gated by the learned body channel.
    slot_mask = torch.arange(n_slots, device=device)[None, :] < active_slots[:, None]
    slot_weights = slot_mask.to(memory.dtype).unsqueeze(-1)
    pooled = (memory * slot_weights).sum(dim=1) / slot_weights.sum(dim=1).clamp_min(1.0)
    body_add = pooled * torch.tanh(resampler.body_gate).to(memory.dtype)
    return memory, recon, ref_ids, ref_lens, body_add


class ReferenceBuffer:
    """Holds recently-seen RAG reference strings so wrong-reference sampling
    for the contrastive loss isn't limited to the current (tiny) micro-batch."""
    def __init__(self, maxlen: int = 128):
        from collections import deque
        self.buf: deque[str] = deque(maxlen=maxlen)

    def add(self, refs: list[str]):
        self.buf.extend(r for r in refs if r)

    def sample_wrong(self, references: list[str], seg_metas, rng: random.Random) -> list[str]:
        wrong = [""] * len(references)
        pool = list(self.buf)
        for i in range(len(references)):
            if not references[i]:
                continue
            candidates = [r for r in pool if r != references[i]]
            if candidates:
                wrong[i] = rng.choice(candidates)
        return wrong


    
_lookup_diag_state = {"correct": 0, "total": 0}
@torch.no_grad()
def log_training_signals(codes, output, seg_metas, tokenizer, lm_model, step, mimi=None, max_print=1):
    """Sanity-check the actual signals flowing through one training step:
    - the real input text (decoded from codes[:,0,:], ground truth)
    - what the model's text head predicts at each frame (argmax of text_logits)
    - whether predictions inside body/ref spans look like real words vs
      collapsed/degenerate output
    - optionally, whether decoding the agent audio codebooks back through
      mimi produces plausible-looking output tokens (not used for training,
      just a signal that codebook 0 isn't saturated)

    Diagnostic-only, gated to fire on a handful of steps so it doesn't
    spam. Never affects the loss or gradients — everything here is under
    @torch.no_grad() and reads output.text_logits, which was already
    computed for the real loss.
    """
    printed = 0
    text_codes = codes[:, 0, :]        # [B, T] ground-truth text stream
    text_logits = output.text_logits[:, 0]  # [B, T, card] — same tensor compute_text_loss_rag uses
    pred_ids = text_logits.argmax(dim=-1)   # [B, T] — greedy decode of what the model WOULD say

    for meta in seg_metas:
        if printed >= max_print:
            return
        b = meta.batch_idx
        body_spans = meta.spans_of("body")
        if not body_spans:
            continue
        s, e = body_spans[0].start_frame, body_spans[0].end_frame
        e = min(e, text_codes.shape[-1])
        if s >= e:
            continue

        def _decode(ids_1d, tag):
            pieces = []
            for i in ids_1d.tolist():
                if i < 0:
                    pieces.append(f"<ZERO:{i}>")
                elif i == lm_model.text_initial_token_id:
                    pieces.append("<INIT>")
                elif i >= tokenizer.GetPieceSize():
                    pieces.append(f"<OOV:{i}>")
                else:
                    pieces.append(tokenizer.id_to_piece(i))
            text = "".join(pieces).replace("▁", " ").strip()
            logger.info(f"[diag-signal] step {step} b={b} body[{s}:{e}] {tag}: {text!r}")
            return text

        gt_text   = _decode(text_codes[b, s:e], "GROUND_TRUTH")
        pred_text = _decode(pred_ids[b, s:e], "MODEL_PRED   ")

        # Cheap degeneracy check: is the model just repeating one token
        # (e.g. collapsed onto a single pad/placeholder id) across the
        # whole body span, regardless of what the ground truth says?
        unique_preds = pred_ids[b, s:e].unique().numel()
        span_len = e - s
        if unique_preds <= 2 and span_len > 5:
            logger.warning(f"[diag-signal] step {step} b={b} DEGENERATE: only "
                            f"{unique_preds} unique predicted token(s) across "
                            f"{span_len} body frames — model may be collapsing")

        # Ref span too, if present — this is the injected/grounding text
        ref_spans = meta.spans_of("ref")
        if ref_spans:
            rs, re_ = ref_spans[0].start_frame, min(ref_spans[0].end_frame, text_codes.shape[-1])
            if rs < re_:
                _decode(text_codes[b, rs:re_], "REF_TEXT     ")
        lookup_spans = meta.spans_of("lookup")
        if lookup_spans:
            lp = lookup_spans[0].start_frame
            if 0 <= lp < text_codes.shape[-1]:
                gt_id = text_codes[b, lp].item()
                pred_id = pred_ids[b, lp].item()
                gt_piece = tokenizer.id_to_piece(gt_id) if 0 <= gt_id < tokenizer.GetPieceSize() else f"<{gt_id}>"
                pred_piece = tokenizer.id_to_piece(pred_id) if 0 <= pred_id < tokenizer.GetPieceSize() else f"<{pred_id}>"
                top5 = text_logits[b, lp].topk(5).indices.tolist()
                logger.info(f"[diag-lookup] step {step} b={b} frame={lp} GT={gt_piece!r} "
                            f"PRED={pred_piece!r} top5={[tokenizer.id_to_piece(i) for i in top5]}")

        printed += 1       

# ---------------------------------------------------------------------------
# Gradient checkpointing
# ---------------------------------------------------------------------------

def enable_gradient_checkpointing(lm: nn.Module) -> None:
    """
    Enable gradient checkpointing on the transformer layers inside LMModel.

    peft's get_peft_model exposes enable_input_require_grads which is needed
    for gradient checkpointing to work when inputs don't have requires_grad.
    Then we enable checkpointing on the underlying transformer modules.
    """
    # peft wrapper
    if hasattr(lm, "enable_input_require_grads"):
        lm.enable_input_require_grads()

    # Enable on the two StreamingTransformer modules
    base = lm.base_model if hasattr(lm, "base_model") else lm
    for name in ("transformer", "depformer"):
        module = getattr(base, name, None)
        if module is not None and hasattr(module, "gradient_checkpointing_enable"):
            module.gradient_checkpointing_enable()
            logger.info(f"gradient checkpointing enabled on lm.{name}")
        elif module is not None:
            # StreamingTransformer may not expose the method directly;
            # wrap its layers manually
            if hasattr(module, "layers"):
                module.gradient_checkpointing = True
                logger.info(f"set gradient_checkpointing=True on lm.{name}")


# ---------------------------------------------------------------------------
# Checkpoint save / load
# ---------------------------------------------------------------------------

def save_checkpoint(out_dir: Path, step: int, lm: nn.Module, resampler: RefResampler,
                     optimizer: torch.optim.Optimizer, scheduler, stats: dict) -> None:
    ckpt_dir = out_dir / f"step_{step}"
    ckpt_dir.mkdir(parents=True, exist_ok=True)
   
    torch.save(lm.state_dict(), ckpt_dir / "lm_state.pt")
    torch.save(resampler.state_dict(), ckpt_dir / "resampler.pt")
    torch.save({
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict() if scheduler else None,
        "step": step, "stats": stats,
    }, ckpt_dir / "optim.pt")
    logger.info(f"[ckpt] saved step {step} → {ckpt_dir}")


def load_checkpoint(ckpt_dir: Path, lm: nn.Module, resampler: RefResampler,
                     optimizer: torch.optim.Optimizer, scheduler) -> int:
    lm_state_path = ckpt_dir / "lm_state.pt"
    if lm_state_path.exists():
        missing, unexpected = lm.load_state_dict(torch.load(lm_state_path), strict=False)
        if missing or unexpected:
            logger.warning(f"[ckpt] lm state: {len(missing)} missing, {len(unexpected)} unexpected keys")

    resampler_path = ckpt_dir / "resampler.pt"
    if resampler_path.exists():
        resampler.load_state_dict(torch.load(resampler_path))
        logger.info(f"[ckpt] loaded resampler from {resampler_path}")

    optim_path = ckpt_dir / "optim.pt"
    if optim_path.exists():
        state = torch.load(optim_path)
        optimizer.load_state_dict(state["optimizer"])
        if scheduler and state.get("scheduler"):
            scheduler.load_state_dict(state["scheduler"])
        step = state["step"]
        logger.info(f"[ckpt] resumed from step {step}")
        return step
    return 0




# ---------------------------------------------------------------------------
# Training step
# ---------------------------------------------------------------------------




def forward_train_checkpointed(self: LMModel, codes: torch.Tensor,
                                seg_metas=None, memory: torch.Tensor | None = None,
                                body_add: torch.Tensor | None = None,
                                use_mem: torch.Tensor | None = None):
    from .models.lm import _delay_sequence, _undelay_sequence, LMOutput
    from torch.utils.checkpoint import checkpoint

    B, K, T = codes.shape
    initial = self._get_initial_token().expand(B, -1, -1)
    delayed = _delay_sequence(self.delays, codes, initial)
    delayed = torch.cat([initial, delayed], dim=2)

    def _embed_and_transform(seq, memory, body_add, use_mem):
        embedded = self.embed_codes(seq)
        if memory is not None and seg_metas is not None:
            S = embedded.shape[1]
            streaming_sum = torch.zeros_like(embedded)
            for m in seg_metas:
                b = m.batch_idx
                # No context for this sample: leave the normal frame embedding.
                if use_mem is not None and use_mem[b] <= 0:
                    continue
                for span in m.spans_of("ref_slot"):
                    s_f, e_f = span.start_frame, span.end_frame
                    n = min(e_f - s_f, memory.shape[1])
                    dst = s_f + 1
                    if n > 0 and 0 <= dst and dst + n <= S:
                        streaming_sum[b, dst:dst + n] += memory[b, :n].to(streaming_sum.dtype)
            if body_add is not None:
                for m in seg_metas:
                    b = m.batch_idx
                    if use_mem is not None and use_mem[b] <= 0:
                        continue
                    for span in m.body_spans():
                        # The delayed training sequence prepends one initial
                        # frame, just like the ref-slot path above.
                        s = max(0, span.start_frame + 1)
                        e = min(S, span.end_frame + 1)
                        if s < e:
                            streaming_sum[b, s:e] += body_add[b].to(streaming_sum.dtype)
            embedded = self.add_streaming_sum(embedded, streaming_sum)
        transformer_dtype = next(self.transformer.parameters()).dtype
        return self.transformer(embedded.to(transformer_dtype))

    transformer_out = checkpoint(_embed_and_transform, delayed[:, :, :-1], memory, body_add,
                                 use_mem, use_reentrant=False)
    if self.out_norm:
        transformer_out = self.out_norm(transformer_out)
    text_logits = self.text_linear(transformer_out)[:, None]

    logits = checkpoint(lambda seq, t_out: self.forward_depformer_training(seq, t_out),
                         delayed[:, :, 1:], transformer_out, use_reentrant=False)

    logits, logits_mask = _undelay_sequence(self.delays[self.audio_offset:self.audio_offset+self.dep_q], logits, fill_value=float("NaN"))
    logits_mask &= codes[:, self.audio_offset:self.audio_offset+self.dep_q] != self.zero_token_id
    text_logits, text_logits_mask = _undelay_sequence(self.delays[:1], text_logits, fill_value=float("NaN"))
    text_logits_mask &= codes[:, :1] != self.zero_token_id
    return LMOutput(logits, logits_mask, text_logits, text_logits_mask)


def _body_logprob(base_lm, codes, seg_metas, resampler, sp_tokenizer, ref_texts,
                  device, args, use_memory: bool):
    """Mean body-token log-prob across ALL grounded turns of each sample.
    `use_memory=False` uses zeroed ref slots (reliance baseline)."""
    pad_id = base_lm.text_padding_token_id
    live_metas = [m for m in seg_metas if m is not None]
    if use_memory:
        memory, _recon, _ref_ids, _ref_lens, body_add = build_ref_memory_batch(
            seg_metas, ref_texts, sp_tokenizer, pad_id, resampler, device, args)
    else:
        memory, body_add = None, None
    if not any(m.body_spans() for m in live_metas):
        return {}
    out = forward_train_checkpointed(base_lm, codes=codes, seg_metas=live_metas,
                                     memory=memory, body_add=body_add)
    logprobs = torch.log_softmax(out.text_logits[:, 0], dim=-1)
    targets = codes[:, 0]
    gathered = logprobs.gather(-1, targets.clamp(min=0).unsqueeze(-1)).squeeze(-1)
    result = {}
    for m in live_metas:
        vals = []
        for span in m.body_spans():
            s, e = max(0, span.start_frame), min(codes.shape[-1], span.end_frame)
            if s >= e:
                continue
            valid = targets[m.batch_idx, s:e] != base_lm.zero_token_id
            if valid.any():
                vals.append(gathered[m.batch_idx, s:e][valid].mean())
        if vals:
            result[m.batch_idx] = torch.stack(vals).mean()
    return result


def log_injection_effect(base_lm, codes, seg_metas, resampler, sp_tokenizer, ref_texts,
                         device, args, step):
    """Directly measure whether the injected context changes the body logits:
    body_logit_delta ~0 (and argmax_flip ~0) => the injection is dead; >0 => it
    reaches the model and the issue is the objective/data."""
    pad_id = base_lm.text_padding_token_id
    live = [m for m in seg_metas if m is not None]
    if not any(m.body_spans() for m in live):
        return
    memory, _r, _ids, _lens, body_add = build_ref_memory_batch(
        seg_metas, ref_texts, sp_tokenizer, pad_id, resampler, device, args)
    if float(memory.detach().abs().sum()) == 0.0:
        return
    with_mem = forward_train_checkpointed(base_lm, codes=codes, seg_metas=live,
                                          memory=memory, body_add=body_add).text_logits[:, 0].detach()
    without = forward_train_checkpointed(base_lm, codes=codes, seg_metas=live,
                                         memory=None, body_add=None).text_logits[:, 0].detach()
    deltas, flips, n = [], 0, 0
    for m in live:
        for span in m.body_spans():
            s, e = max(0, span.start_frame), min(codes.shape[-1], span.end_frame)
            if s >= e:
                continue
            d = (with_mem[m.batch_idx, s:e] - without[m.batch_idx, s:e])
            deltas.append(d.abs().mean())
            flips += int((with_mem[m.batch_idx, s:e].argmax(-1)
                          != without[m.batch_idx, s:e].argmax(-1)).sum().item())
            n += (e - s)
    if deltas:
        logger.info(f"[inject-effect] step {step} body_logit_delta={torch.stack(deltas).mean().item():.4f} "
                    f"body_argmax_flip={flips / max(n, 1):.3f} n={n}")


def compute_copy_loss(text_logits, codes, seg_metas, ref_ids, ref_lens, weight):
    """Copy-forcing loss: the body frames must be predictable as the reference
    tokens (position-aligned). This directly rewards reading/regurgitating the
    injected context, so the model can't satisfy the body purely from prior."""
    logits = text_logits[:, 0]
    T = logits.shape[1]
    terms = []
    for m in seg_metas:
        if m is None:
            continue
        b = m.batch_idx
        n_ref = int(ref_lens[b].item())
        spans = m.body_spans()
        if n_ref <= 0 or not spans:
            continue
        s = max(0, spans[0].start_frame)
        e = min(T, spans[-1].end_frame)
        n = min(e - s, n_ref)
        if n <= 0:
            continue
        lg = torch.nan_to_num(logits[b, s:s + n].float(), nan=0.0, posinf=0.0, neginf=0.0)
        terms.append(F.cross_entropy(lg, ref_ids[b, :n]))
    if not terms:
        return torch.tensor(0.0, device=text_logits.device)
    return weight * torch.stack(terms).mean()


def compute_grounding_losses(base_lm, codes, seg_metas, resampler, sp_tokenizer,
                             correct_refs, wrong_refs, device, args, step):
    """Contrastive (correct vs wrong ref) + reliance (with vs without frames)."""
    correct_lp = _body_logprob(base_lm, codes, seg_metas, resampler, sp_tokenizer,
                               correct_refs, device, args, use_memory=True)

    contrastive = torch.tensor(0.0, device=device)
    if step >= args.contrastive_start_step:
        wrong_lp = _body_logprob(base_lm, codes, seg_metas, resampler, sp_tokenizer,
                                 wrong_refs, device, args, use_memory=True)
        gaps = [correct_lp[b].item() - wrong_lp[b].item() for b in correct_lp if b in wrong_lp]
        if gaps:
            logger.info(f"[contrastive] mean_gap={sum(gaps)/len(gaps):.4f} n={len(gaps)}")
        losses = [F.relu(args.contrastive_margin - (correct_lp[b] - wrong_lp[b]))
                  for b in correct_lp if b in wrong_lp]
        if losses:
            contrastive = torch.stack(losses).mean() * args.contrastive_weight

    reliance = torch.tensor(0.0, device=device)
    if args.reliance_weight > 0 and step >= args.reliance_start_step:
        noref_lp = _body_logprob(base_lm, codes, seg_metas, resampler, sp_tokenizer,
                                 correct_refs, device, args, use_memory=False)
        rl = [F.relu(args.reliance_margin - (correct_lp[b] - noref_lp[b]))
              for b in correct_lp if b in noref_lp]
        if rl:
            reliance = torch.stack(rl).mean() * args.reliance_weight
    return contrastive, reliance


def training_step(batch, lm, resampler, ref_buffer, args, rng, device, tokenizer, sp_tokenizer,
                   step=0, diag_every=40, do_backward=True):
    codes = batch.codes.to(device)
    
    last_frame_text = codes[:, 0, -1]
    bad_last = (last_frame_text >= lm.text_card + 1) | ((last_frame_text < 0) & (last_frame_text != lm.zero_token_id))
    if bad_last.any():
        bad_batch_idxs = bad_last.nonzero(as_tuple=True)[0].tolist()
        bad_vals = last_frame_text[bad_last].tolist()
        raise ValueError(f"[step {step}] codes[:,0,-1] (the exclusive depformer_text_emb frame) "
                          f"has out-of-range ids at batch idx {bad_batch_idxs}: {bad_vals} "
                          f"(text_card={lm.text_card})")
        
    seg_metas = batch.segment_metas
    base_lm = lm
    pad_id = lm.text_padding_token_id

    ref_texts = [batch.reference_texts[m.batch_idx] if m is not None else "" for m in seg_metas]
    ref_buffer.add([t for t in ref_texts if t])
    wrong_texts = ref_buffer.sample_wrong(ref_texts, seg_metas, rng)

    memory, recon_loss, ref_ids, ref_lens, body_add = build_ref_memory_batch(
        seg_metas, ref_texts, sp_tokenizer, pad_id, resampler, device, args)
    filtered_metas = [m for m in seg_metas if m is not None]

    # Optional robustness dropout. Keep this disabled for the grounding run:
    # supervising the same answer with no context teaches the LM to ignore the
    # injected reference.
    use_mem = None
    if args.frame_dropout > 0:
        drop = torch.rand(codes.shape[0], device=device) < args.frame_dropout
        use_mem = (~drop).float()
        memory = memory * use_mem[:, None, None]
        body_add = body_add * use_mem[:, None]

    if step % diag_every == 0:
        with torch.no_grad():
            n_live = int((memory.abs().sum(dim=(1, 2)) > 0).sum().item())
            ref_frames = sum(
                max(0, s.end_frame - s.start_frame)
                for m in filtered_metas for s in m.spans_of("ref_slot"))
            logger.info(
                f"[inject] step {step} live={n_live} ref_frames={ref_frames} "
                f"mem_norm={memory.norm(dim=-1).mean().item():.3f} "
                f"scale={float(resampler.output_scale.detach()):.3f} "
                f"body_gate={float(torch.tanh(resampler.body_gate.detach())):.4f}")

    output = forward_train_checkpointed(base_lm, codes=codes,
                                        seg_metas=filtered_metas,
                                        memory=memory, body_add=body_add, use_mem=use_mem)

    if step % diag_every == 0:
        log_training_signals(codes, output, filtered_metas, tokenizer, base_lm, step)
        log_injection_effect(base_lm, codes, seg_metas, resampler, sp_tokenizer, ref_texts, device, args, step)

    text_loss, audio_loss = compute_rag_losses(model=base_lm, output=output, codes=codes,
                                                seg_metas=filtered_metas, args=args)

    contrastive_loss = torch.tensor(0.0, device=device)
    reliance_loss = torch.tensor(0.0, device=device)
    if any(wrong_texts) and step >= min(args.contrastive_start_step, args.reliance_start_step):
        contrastive_loss, reliance_loss = compute_grounding_losses(
            base_lm, codes, seg_metas, resampler, sp_tokenizer,
            ref_texts, wrong_texts, device, args, step)

    # Undiluted <lookup> trigger CE (the weighted-mean text loss dilutes a
    # single rare frame to ~0). This is what teaches the model to emit the
    # trigger itself on every RAG turn.
    lookup_ce = compute_lookup_ce(output.text_logits, codes, filtered_metas,
                                  weight=args.lookup_ce_weight)

    # Copy-forcing: reward the body for matching the reference tokens (so the
    # model can't win purely from prior knowledge).
    copy_loss = compute_copy_loss(output.text_logits, codes, filtered_metas,
                                  ref_ids, ref_lens, weight=args.copy_weight)

    loss = (text_loss + audio_loss + contrastive_loss + reliance_loss
            + args.recon_weight * recon_loss + lookup_ce + copy_loss)
    if do_backward:
        loss.backward()

    return {"loss": loss.item(), "text_loss": text_loss.item(), "audio_loss": audio_loss.item(),
            "contrastive": contrastive_loss.item(), "reliance": reliance_loss.item(),
            "lookup": lookup_ce.item(), "copy": copy_loss.item(),
            "recon": float(recon_loss.detach())}
    


# ---------------------------------------------------------------------------
# Main training loop
# ---------------------------------------------------------------------------

def train(args: argparse.Namespace) -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
    )
    device = torch.device(args.device)

    # ── Load models ───────────────────────────────────────────────────────
    logger.info("loading tokenizer")
    if args.tokenizer is None:
        args.tokenizer = hf_hub_download(args.hf_repo, loaders.TEXT_TOKENIZER_NAME)
    tokenizer = sentencepiece.SentencePieceProcessor(args.tokenizer)

    logger.info("loading mimi (frozen)")
    if args.mimi_weight is None:
        args.mimi_weight = hf_hub_download(args.hf_repo, loaders.MIMI_NAME)
    mimi = loaders.get_mimi(args.mimi_weight, device)
    mimi.eval()
    for p in mimi.parameters():
        p.requires_grad_(False)   # Mimi never trains

    logger.info("loading moshi LM")
    if args.moshi_weight is None:
        args.moshi_weight = hf_hub_download(args.hf_repo, loaders.MOSHI_NAME)
    lm_base: LMModel = loaders.get_moshi_lm(args.moshi_weight, device=device, cpu_offload=False)
    lm_base.eval()
    model_dtype = next(lm_base.parameters()).dtype
    lm_base = lm_base.to(dtype=model_dtype)
    
    # ── NEW: verify/grow vocab for <lookup> ──
    from .interleaver import lookup_id, ref_id
    lookup_token_id = lookup_id(tokenizer)
    if lookup_token_id == tokenizer.unk_id():
        raise ValueError("<lookup> is not a piece in the tokenizer vocab — add it before training")
    
    ref_token_id = ref_id(tokenizer)
    if ref_token_id == tokenizer.unk_id():
        raise ValueError("<ref> is not a piece in the tokenizer vocab — add it before training")
    
    tokenizer_vocab_size = tokenizer.GetPieceSize()
    original_text_card = lm_base.text_card
    required_text_card = max(tokenizer_vocab_size, lookup_token_id + 1, ref_token_id + 1)
    
    if required_text_card > lm_base.text_card:
        n_new = required_text_card - lm_base.text_card
        logger.info(f"tokenizer vocab_size={tokenizer_vocab_size}, lookup_id={lookup_token_id}, "
                    f"model text_card={lm_base.text_card} — growing by {n_new} to cover full tokenizer vocab")
        lm_base.grow_text_vocab(n_new=n_new)
    else:
        logger.info(f"tokenizer vocab_size={tokenizer_vocab_size} already within text_card={lm_base.text_card}, no resize needed")

    
    lora_params = apply_lora_to_streaming_attention(
        lm_base, rank=args.lora_rank, alpha=args.lora_rank * args.lora_scaling,
        include_depformer=False)
    lm = lm_base

    # Only rows appended for the tokenizer/control tokens may train. This
    # preserves the pretrained text behavior and the voice-prompt padding row.
    new_row_start = original_text_card
    new_row_end = lm_base.text_card

    def _keep_new_rows(grad, start=new_row_start, end=new_row_end):
        masked = torch.zeros_like(grad)
        if end > start:
            masked[start:end] = grad[start:end]
        return masked

    if args.ft_embed and new_row_end > new_row_start:
        for mod in (lm_base.text_emb, lm_base.depformer_text_emb):
            for p in mod.parameters():
                p.requires_grad_(True)
            mod.weight.register_hook(_keep_new_rows)
        logger.info(f"[opt] training only new text embedding rows [{new_row_start}, {new_row_end})")
    elif args.ft_embed:
        logger.info("[opt] no new text embedding rows; pretrained text embeddings remain frozen")
    else:
        logger.info("[opt] text embeddings frozen (--no-ft-embed)")
    for p in lm_base.text_linear.parameters():
        p.requires_grad_(True)
    lm_base.text_linear.weight.register_hook(_keep_new_rows)
    if lm_base.text_linear.bias is not None:
        lm_base.text_linear.bias.register_hook(_keep_new_rows)

    d_model = lm_base.text_emb.embedding_dim
    
    resampler = RefResampler(
        text_emb=lm_base.text_emb, context_dim=d_model,
        n_ref_slots=args.n_ref_slots,n_layers=args.resampler_layers,
        device=device, dtype=torch.float32,
        soft_token=args.soft_token, soft_tau=args.soft_tau, hard_token=args.hard_token,
        norm_out=args.norm_out,
    )
    
    if args.gradient_checkpointing:
        enable_gradient_checkpointing(lm)
    lm.train()
    resampler.train()
    
    new_text_params = list(lm_base.text_linear.parameters())
    if args.ft_embed:
        new_text_params = (
            list(lm_base.text_emb.parameters())
            + list(lm_base.depformer_text_emb.parameters())
            + new_text_params
        )

    # text_emb is shared with the resampler (which holds a reference to it);
    # keep it in a single group so the same Parameter isn't handed to two groups.
    # Gate/scale scalars go in their OWN group with weight_decay=0: AdamW's
    # decoupled decay would otherwise pull them toward 0 and fight the injection.
    gate_names = ("output_scale", "body_gate")
    resampler_params = [
        p for n, p in resampler.named_parameters()
        if p.requires_grad and not n.startswith("text_emb.") and n not in gate_names
    ]
    gate_params = [getattr(resampler, n) for n in gate_names]

    optimizer = AdamW([
        {"name": "lora",      "params": lora_params, "lr": args.lr, "weight_decay": args.weight_decay},
        {"name": "text",      "params": new_text_params, "lr": args.text_lr, "weight_decay": 0.0},
        {"name": "resampler", "params": resampler_params,
         "lr": args.resampler_lr, "weight_decay": args.weight_decay},
        {"name": "resampler_gate", "params": gate_params,
         "lr": args.gate_lr, "weight_decay": 0.0},
    ], betas=(0.9, 0.95), eps=1e-8)
    
    resampler_group = next(g for g in optimizer.param_groups if g["name"] == "resampler")
    
    
    from torch.optim.lr_scheduler import LambdaLR
    def _resampler_warmup_then_cosine(step):
        warmup = args.resampler_warmup_steps
        if step < warmup:
            return step / max(1, warmup)
        progress = (step - warmup) / max(1, args.max_steps - warmup)
        return 0.5 * (1 + torch.cos(torch.tensor(progress * 3.14159265))).item()
    
    base_scheduler = CosineAnnealingLR(optimizer, T_max=args.max_steps, eta_min=args.lr * 0.1)
    scheduler = base_scheduler

    # ── Dataset ───────────────────────────────────────────────────────────
    interleaver = Interleaver(
        tokenizer=tokenizer, audio_frame_rate=mimi.frame_rate,
        text_padding=lm_base.text_padding_token_id,
        end_of_text_padding=lm_base.end_of_text_padding_id,
        zero_padding=lm_base.zero_token_id,
        keep_main_only=True,
        use_bos_eos=True,
        main_speaker_label="ASSISTANT",   # matches InterleavedTokenizer.agent_speaker_label
        device=str(device),
    )
    instruct_tokenizer = InterleavedTokenizer(
        mimi=mimi, interleaver=interleaver, duration_sec=args.duration_sec,
        n_ref_slots=args.n_ref_slots,
        max_ref_source_tokens=args.max_ref_source_tokens,
        ref_tokens_per_slot=args.ref_tokens_per_slot,
        min_ref_slots=args.min_ref_slots,
        target_n_audio_codebooks = 16,
        text_card=lm_base.text_card,   
        ref_mode="slots",   # <ref> [K zero] <ref> block, embeddings replaced
        silence_hold=False,  # keep the real lead/filler hold (it's in the audio)
        ref_slots_after_query=True,   # context right after the <lookup> trigger
    )
    data_dir = Path(args.data_dir)
    from .interleaver import split_train_val

    if args.eval_data:
        train_manifest, eval_manifest = args.train_data, args.eval_data
    else:
        with open(args.train_data) as f:
            all_lines = [line for line in f if line.strip()]
        train_lines, val_lines = split_train_val(all_lines, val_fraction=args.val_fraction, seed=args.split_seed)
        train_manifest_path = data_dir / "train_split.jsonl"
        eval_manifest_path  = data_dir / "val_split.jsonl"
        data_dir.mkdir(parents=True, exist_ok=True)
        train_manifest_path.write_text("".join(train_lines))
        eval_manifest_path.write_text("".join(val_lines))
        train_manifest, eval_manifest = str(train_manifest_path), str(eval_manifest_path)
        logger.info(f"[split] {len(train_lines)} train / {len(val_lines)} val "
                    f"({args.val_fraction:.0%} held out, seed={args.split_seed})")
    
    args.train_data = train_manifest
    args.eval_data  = eval_manifest

    train_loader = build_data_loader(
        instruct_tokenizer=instruct_tokenizer,
        args=args,
        batch_size=args.batch_size,
        seed=42,
        rank=0,
        world_size=1,
        is_eval=False,
    )
    eval_loader = build_data_loader(
        instruct_tokenizer=instruct_tokenizer,
        args=args,
        batch_size=args.batch_size,
        seed=0,
        rank=0,
        world_size=1,
        is_eval=True,
    ) if args.eval_data else None

    # ── Resume ────────────────────────────────────────────────────────────
    start_step = 0
    if args.resume:
        start_step = load_checkpoint(Path(args.resume), lm, resampler, optimizer, scheduler)

    # ── Training loop ─────────────────────────────────────────────────────
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rng = random.Random(42)
    step = start_step
    log_interval  = args.log_every
    eval_interval = args.eval_every
    save_interval = args.save_every

    running = {k: 0.0 for k in ("loss", "text_loss", "audio_loss", "contrastive", "reliance", "lookup", "copy", "recon")}
    running_n = 0
    t0 = time.time()

    logger.info(f"starting training from step {step}")

    optimizer.zero_grad()
    accum_steps = 0

    ref_buffer = ReferenceBuffer()  

    for batch in train_loader:
        if step >= args.max_steps:
            break

        scalars = training_step(
            batch=batch, lm=lm, resampler=resampler,
            ref_buffer=ref_buffer, args=args, rng=rng, device=device,
            tokenizer=tokenizer, sp_tokenizer=tokenizer, step=step,   # <-- add
        )
        accum_steps += 1
        for k, v in scalars.items():
            running[k] += v
        running_n += 1

        if accum_steps >= args.grad_accum:
            torch.nn.utils.clip_grad_norm_(
                list(lm.parameters()) + list(resampler.parameters()), max_norm=1.0,
            )
            optimizer.step()
            scheduler.step()
            if step < args.resampler_warmup_steps:
                resampler_group['lr'] = args.resampler_lr * (step + 1) / args.resampler_warmup_steps
            optimizer.zero_grad()
            step += 1
            accum_steps = 0

            # ── Logging ───────────────────────────────────────────────────
            if step % log_interval == 0:
                elapsed = time.time() - t0
                avg     = {k: running[k] / max(running_n, 1) for k in running}
                lr      = scheduler.get_last_lr()[0]
                logger.info(
                    f"step {step:5d}/{args.max_steps} "
                    f"loss={avg['loss']:.4f} "
                    f"text={avg['text_loss']:.4f} "
                    f"audio={avg['audio_loss']:.4f} "
                    f"contrastive={avg['contrastive']:.4f} "
                    f"reliance={avg['reliance']:.4f} "
                    f"lookup={avg['lookup']:.4f} "
                    f"copy={avg['copy']:.4f} "
                    f"recon={avg['recon']:.4f} "
                    f"lr={lr:.2e} "
                    f"elapsed={elapsed:.0f}s"
                )
                running   = {k: 0.0 for k in running}
                running_n = 0

            # ── Eval ──────────────────────────────────────────────────────
            if eval_loader is not None and step % eval_interval == 0:
                lm.eval()
                resampler.eval()
                eval_losses = {k: 0.0 for k in ("loss", "text_loss", "audio_loss", "contrastive", "reliance", "lookup", "copy", "recon")}
                eval_n = 0
                with torch.no_grad():
                    for eval_batch in eval_loader:
                        s = training_step(
                            batch=eval_batch, lm=lm, resampler=resampler,
                            ref_buffer=ref_buffer, args=args, rng=rng, device=device,
                            tokenizer=tokenizer, sp_tokenizer=tokenizer, step=step,
                            do_backward=False, 
                        )
                        for k in eval_losses:
                            eval_losses[k] += s.get(k, 0.0)
                        eval_n += 1
                        if eval_n >= 50:
                            break
                avg_eval = {k: v / max(eval_n, 1) for k, v in eval_losses.items()}
                logger.info(f"[eval] step {step} loss={avg_eval['loss']:.4f} text={avg_eval['text_loss']:.4f} "
                f"audio={avg_eval['audio_loss']:.4f} contrastive={avg_eval['contrastive']:.4f} "
                f"reliance={avg_eval['reliance']:.4f} lookup={avg_eval['lookup']:.4f} "
                f"copy={avg_eval['copy']:.4f} recon={avg_eval['recon']:.4f}")
                lm.train()
                resampler.train()

            if step % save_interval == 0:
                save_checkpoint(out_dir, step, lm, resampler, optimizer, scheduler, stats={"step": step})

    save_checkpoint(out_dir, step, lm, resampler, optimizer, scheduler, stats={"step": step, "final": True})
    
    logger.info(f"training complete at step {step}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Data
    ap.add_argument("--train-data",  required=True, help="train.jsonl manifest path")
    ap.add_argument("--data-dir",  default="/workspace/train/temp_data", help="save temp train and val data")
    ap.add_argument("--eval-data",   default="",    help="eval.jsonl manifest path (optional)")
    ap.add_argument("--duration-sec", type=float, default=100.0)
    ap.add_argument("--batch-size",   type=int,   default=16)

    # Model
    ap.add_argument("--hf-repo",      default=loaders.DEFAULT_REPO)
    ap.add_argument("--moshi-weight", default=None)
    ap.add_argument("--mimi-weight",  default=None)
    ap.add_argument("--tokenizer",    default=None)
    ap.add_argument("--device",       default="cuda")
    ap.add_argument("--val-fraction", type=float, default=0.1,
                help="Fraction of --train-data held out for validation. Ignored if --eval-data is explicitly given.")
    ap.add_argument("--split-seed", type=int, default=0)

    # LoRA
    ap.add_argument("--lora-rank",    type=int,   default=128)
    ap.add_argument("--lora-scaling", type=float, default=2.0)
    ap.add_argument("--ft-embed", action=argparse.BooleanOptionalAction, default=True,
                    help="Train only newly appended text embedding/output rows; "
                         "pretrained rows remain frozen.")
    ap.add_argument("--gradient-checkpointing", action="store_true", default=True)

    ap.add_argument("--n-ref-slots", type=int, default=32,
                     help="Maximum compressed context frames per reference")
    ap.add_argument("--max-ref-source-tokens", type=int, default=300,
                     help="Cap on raw reference tokens the resampler reads; does NOT affect main sequence length")
    ap.add_argument("--ref-tokens-per-slot", type=int, default=4,
                     help="Reference tokens represented by one active context slot")
    ap.add_argument("--min-ref-slots", type=int, default=1,
                     help="Minimum active slots for a nonempty reference")
    ap.add_argument("--resampler-lr", type=float, default=1e-4,
                     help="Separate LR for the resampler/compressor — trained from scratch")
    ap.add_argument("--gate-lr", type=float, default=2e-4,
                     help="LR for the injection gates/scales (output_scale, body_gate); "
                          "weight decay is disabled for this group.")
    ap.add_argument("--text-lr", type=float, default=1e-4,
                     help="LR for the text head/embeddings — the new <lookup>/<ref> "
                          "rows are zero-init and need to grow.")
    ap.add_argument("--soft-token", action=argparse.BooleanOptionalAction, default=False,
                     help="Decode each compressed frame as a convex combination of real "
                          "token embeddings. Default OFF: emit expressive in-space vectors "
                          "(the aux vocab_proj head still keeps them content-bearing via "
                          "the reconstruction loss).")
    ap.add_argument("--hard-token", action=argparse.BooleanOptionalAction, default=False,
                     help="Straight-through hard tokens (only with --soft-token).")
    ap.add_argument("--soft-tau", type=float, default=1.0,
                     help="Temperature of the soft-token distribution.")
    ap.add_argument("--norm-out", action=argparse.BooleanOptionalAction, default=True,
                     help="LayerNorm the emitted context vectors. The base model's "
                          "embeddings are RAW (ScaledEmbedding norm off), so --no-norm-out "
                          "matches its convention more closely.")


    # Optimiser
    ap.add_argument("--lr",           type=float, default=1e-5,
                    help="LR for the LoRA adapters — this is what learns to READ the "
                         "injected frames; 2e-6 converges very slowly.")
    ap.add_argument("--weight-decay", type=float, default=0.1)
    ap.add_argument("--max-steps",    type=int,   default=12000)
    ap.add_argument("--grad-accum",   type=int,   default=1,
                    help="Gradient accumulation steps (default: 1)")

    # Loss weights
    ap.add_argument("--first-codebook-weight", dest="first_codebook_weight_multiplier",
                    type=float, default=100.0)
    ap.add_argument("--num-agent-codebooks", type=int, default=8,
                 help="Only the first N audio codebooks (agent/assistant channel) "
                      "count toward audio loss — user channel is input, never a "
                      "generation target")
    ap.add_argument("--text-padding-weight",   type=float, default=0.1)
    ap.add_argument("--ref-token-weight",      type=float, default=2.0)
    ap.add_argument("--lead-weight",           type=float, default=1.0)
    ap.add_argument("--filler-weight",         type=float, default=0.5)
    ap.add_argument("--body-weight",           type=float, default=4.0)
    ap.add_argument("--no-rag-weight",         type=float, default=1.0)
    ap.add_argument("--lookup-loss-weight", type=float, default=8.0,
                help="Per-frame weight of the <lookup> frame inside the weighted "
                     "text loss (small, diluted).")
    ap.add_argument("--lookup-ce-weight", type=float, default=1.0,
                help="Weight of the SEPARATE undiluted CE on the <lookup> frame — "
                     "this is what actually teaches the trigger.")
    ap.add_argument("--contrastive-weight",    type=float, default=1.0)
    ap.add_argument("--contrastive-margin",    type=float, default=0.5)
    ap.add_argument("--contrastive-start-step", type=int, default=100)
    ap.add_argument("--reliance-weight", type=float, default=1.0,
                    help="body_lp(with streaming sum) vs body_lp(without): forces the "
                         "model to actually read the injected context.")
    ap.add_argument("--reliance-margin", type=float, default=0.5)
    ap.add_argument("--reliance-start-step", type=int, default=100)
    ap.add_argument("--recon-weight", type=float, default=0.5,
                    help="Order-aware chunked reconstruction of the reference from the K frames. "
                         "Auxiliary; keep below the main objective so it doesn't dominate.")
    ap.add_argument("--copy-weight", type=float, default=0.0,
                    help="Copy-forcing CE: body frames must match the reference tokens. Off by "
                         "default — it is positional and fights the body CE when the answer "
                         "paraphrases. Re-enable if the body should be verbatim.")
    ap.add_argument("--frame-dropout", type=float, default=0.0,
                     help="Optional probability of skipping context; keep at 0 for grounding training.")

    # Checkpointing / logging
    ap.add_argument("--out-dir",    default="ckpts/rag_lora")
    ap.add_argument("--resume",     default=None,
                    help="Path to checkpoint directory to resume from")
    ap.add_argument("--save-every", type=int, default=4000)
    ap.add_argument("--log-every",  type=int, default=100)
    ap.add_argument("--eval-every", type=int, default=1000)
    ap.add_argument("--contrastive-every", type=int, default=4)

    ap.add_argument("--resampler-layers", type=int, default=4,
    help="Depth of cross+self-attn reasoning blocks in RefResampler")
    ap.add_argument("--compress-ratio", type=int, default=4,
                help="Resampler compression: 1 output latent per N input tokens")
    ap.add_argument("--resampler-warmup-steps", type=int, default=200,
        help="Linear LR warmup steps for the resampler param group only — "
             "it's a fresh, deep, randomly-initialized adapter feeding "
             "directly into the LM's embedding stream")

    # DataArgs compatibility (required by build_data_loader)
    ap.add_argument("--shuffle", action="store_true", default=True)

    args = ap.parse_args()

    # Expose as DataArgs-compatible attributes
    args.train_data = args.train_data
    args.eval_data  = args.eval_data

    with torch.no_grad():
        pass   # not wrapping train() — we need gradients

    train(args)


if __name__ == "__main__":
    main()
