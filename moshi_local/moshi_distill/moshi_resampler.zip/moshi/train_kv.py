"""
train_sticky_kv.py
==================
Alternative RAG fine-tuning script that delivers the reference out-of-band
through the model's sticky-latent K/V memory instead of occupying stream time.

Why this exists
---------------
The literal-text method (`<ref> ... <ref>` spliced as real tokens) gave the best
quality but costs one frame per token (~80 ms at 12.5 Hz), so a 150-token
reference forces ~12 s of silence — unusable for a live tool-call turn.

The slot-replacement method (`train_latent.py`) caps that to n_ref_slots frames
but still burns stream time and forces the LM to consume out-of-distribution
"fake token" embeddings.

This setup keeps the resampler compression but injects the latents as extra
attention K/V (`StickyLatentMemory`), which does not occupy stream time:

    user speech
      -> model emits <lookup>  (decision)
      -> host retrieves / runs tools
      -> resampler -> latents written to sticky K/V
      -> model generates the grounded body, then context clears

Training matches that contract:
  * interleaver `ref_mode="sticky"` — only the <lookup> decision frame is
    spliced; no <ref>/ref-slot block.
  * the reference latents are set with `sticky_kv.set_training_context(...)`,
    gated per query frame so they are visible only from the <lookup> frame
    through the grounded body (so the model must commit to <lookup> first).
  * losses: weighted text CE (body is the real "did you use it" signal),
    audio CE, the dedicated <lookup> trigger head, and a contrastive term that
    pushes correct-reference body log-probs above wrong-reference ones.

Optimizer notes (same fixes as train_latent.py): LoRA factors and the resampler
run in fp32 (bf16 master weights round lr~2e-6 updates away to zero), the base
adapter modules are explicitly unfrozen, and text_emb is trained only with
--ft-embed. The personaplex backbone itself stays bf16.

Usage
-----
    python -m moshi.train_sticky_kv \
        --train-data data/train.jsonl \
        --moshi-weight /path/to/moshi.safetensors \
        --mimi-weight  /path/to/mimi.safetensors \
        --tokenizer    /path/to/tokenizer.model \
        --out-dir      checkpoints/rag_sticky \
        --device       cuda
"""

from __future__ import annotations

import argparse
import logging
import os
os.environ.setdefault("CUDA_LAUNCH_BLOCKING", "1")
import random
import time
from pathlib import Path

import torch
import torch.nn.functional as F
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from huggingface_hub import hf_hub_download

from .models import loaders
from .models.lm import LMModel

from .rag_loss_new import compute_rag_losses
from .dataset import build_data_loader
from .interleaver_latent import Interleaver, InterleavedTokenizer, lookup_id, ref_id, split_train_val
from .modules.text_resampler import RefResampler

# Shared, mode-agnostic helpers from the slot-replacement trainer.
from .train_latent import (
    apply_lora_to_streaming_attention,
    _sp_encode_batch,
    ReferenceBuffer,
    save_checkpoint,
    load_checkpoint,
    enable_gradient_checkpointing,
    log_training_signals,
)

import sentencepiece

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Reference latents + per-frame sticky activation
# ---------------------------------------------------------------------------

def build_ref_latents_batch(seg_metas, ref_texts, sp_tokenizer, pad_id, resampler, device, args):
    """[B, n_ref_slots, dim] latents + [B, n_ref_slots] slot mask.

    Unlike the slot-replacement path, "live" is determined by the presence of a
    reference + a body span (there are no ref_slot spans in sticky mode)."""
    B = len(seg_metas)
    dim = resampler.context_dim
    n = args.n_ref_slots
    slot_dtype = resampler.out_proj.weight.dtype
    latents = torch.zeros(B, n, dim, device=device, dtype=slot_dtype)
    slot_mask = torch.zeros(B, n, device=device, dtype=torch.float32)

    live = [(i, t) for i, (m, t) in enumerate(zip(seg_metas, ref_texts))
            if m is not None and t and m.body_start >= 0]
    if not live:
        return latents, slot_mask

    input_ids, attn_mask = _sp_encode_batch(
        sp_tokenizer, [t for _, t in live], args.max_ref_source_tokens, pad_id, device
    )
    lifted, _valid = resampler.encode_slots(input_ids, attn_mask)
    for j, (i, _t) in enumerate(live):
        latents[i] = lifted[j]
        slot_mask[i] = 1.0
    return latents, slot_mask


def build_sticky_active_mask(B: int, S: int, seg_metas, device, enabled: bool = True):
    """[B, S] float mask: 1 on frames where the sticky context is allowed.

    Built over EVERY grounded turn (`SegmentMeta.rag_turn_groups`), not just the
    first, from the context marker (<ref> cue or <lookup>) through that body's
    end, so the model cannot read the reference before deciding it needs one."""
    active = torch.zeros(B, S, device=device, dtype=torch.float32)
    if not enabled:
        return active
    for m in seg_metas:
        if m is None:
            continue
        for start, end in m.rag_turn_groups():
            s, e = max(0, start), min(S, end)
            if s < e:
                active[m.batch_idx, s:e] = 1.0
    return active


# ---------------------------------------------------------------------------
# Forward — same as forward_train_checkpointed but sticky-KV instead of
# embedding replacement.
# ---------------------------------------------------------------------------

def forward_train_sticky(self: LMModel, codes: torch.Tensor, seg_metas=None,
                         ref_latents: torch.Tensor | None = None,
                         ref_slot_mask: torch.Tensor | None = None,
                         ref_active: torch.Tensor | None = None):
    from .models.lm import _delay_sequence, _undelay_sequence, LMOutput
    from torch.utils.checkpoint import checkpoint

    B, K, T = codes.shape
    initial = self._get_initial_token().expand(B, -1, -1)
    delayed = _delay_sequence(self.delays, codes, initial)
    delayed = torch.cat([initial, delayed], dim=2)

    def _embed_and_transform(seq, ref_latents, ref_slot_mask, ref_active):
        audio_sum = None
        for cb_index in range(self.num_audio_codebooks):
            audio_emb = self.emb[cb_index](seq[:, cb_index + self.audio_offset])
            audio_sum = audio_emb if audio_sum is None else audio_sum + audio_emb
        text_emb = self.text_emb(seq[:, 0])
        embedded = audio_sum + text_emb

        # Side-effectful but checkpoint-safe: the context tensors are function
        # inputs, and the body re-runs (and re-sets) them on recomputation.
        if ref_latents is not None:
            self.sticky_kv.set_training_context(
                ref_latents, ref_slot_mask, ref_latents.mean(dim=1), ref_active,
            )
        else:
            self.sticky_kv.clear_training_context()

        transformer_dtype = next(self.transformer.parameters()).dtype
        return self.transformer(embedded.to(transformer_dtype))

    transformer_out = checkpoint(
        _embed_and_transform, delayed[:, :, :-1],
        ref_latents, ref_slot_mask, ref_active, use_reentrant=False,
    )
    if self.out_norm:
        transformer_out = self.out_norm(transformer_out)
    text_logits = self.text_linear(transformer_out)[:, None]

    logits = checkpoint(lambda seq, t_out: self.forward_depformer_training(seq, t_out),
                        delayed[:, :, 1:], transformer_out, use_reentrant=False)

    logits, logits_mask = _undelay_sequence(
        self.delays[self.audio_offset:self.audio_offset + self.dep_q], logits, fill_value=float("NaN"))
    logits_mask &= codes[:, self.audio_offset:self.audio_offset + self.dep_q] != self.zero_token_id
    text_logits, text_logits_mask = _undelay_sequence(self.delays[:1], text_logits, fill_value=float("NaN"))
    text_logits_mask &= codes[:, :1] != self.zero_token_id
    return LMOutput(logits, logits_mask, text_logits, text_logits_mask)


def _body_logprob(base_lm, codes, seg_metas, resampler, sp_tokenizer, ref_texts,
                  device, args, use_memory: bool):
    """Mean log-prob of the ground-truth tokens across ALL body spans of each
    sample (multi-turn aware). With `use_memory=False` the sticky memory is
    masked out, giving the "no context" baseline for the reliance loss."""
    pad_id = base_lm.text_padding_token_id
    S = codes.shape[-1]
    live_metas = [m for m in seg_metas if m is not None]
    if not any(m.body_spans() for m in live_metas):
        return {}

    if use_memory:
        ref_latents, ref_slot_mask = build_ref_latents_batch(
            seg_metas, ref_texts, sp_tokenizer, pad_id, resampler, device, args)
    else:
        ref_latents, ref_slot_mask = None, None
    active = build_sticky_active_mask(codes.shape[0], S, live_metas, device, enabled=use_memory)

    out = forward_train_sticky(
        base_lm, codes=codes, seg_metas=live_metas,
        ref_latents=ref_latents, ref_slot_mask=ref_slot_mask, ref_active=active)
    logprobs = torch.log_softmax(out.text_logits[:, 0], dim=-1)
    targets = codes[:, 0]
    gathered = logprobs.gather(-1, targets.clamp(min=0).unsqueeze(-1)).squeeze(-1)

    result = {}
    for m in live_metas:
        vals = []
        for span in m.body_spans():
            s, e = max(0, span.start_frame), min(S, span.end_frame)
            if s >= e:
                continue
            valid = targets[m.batch_idx, s:e] != base_lm.zero_token_id
            if valid.any():
                vals.append(gathered[m.batch_idx, s:e][valid].mean())
        if vals:
            result[m.batch_idx] = torch.stack(vals).mean()
    return result


def compute_grounding_losses(base_lm, codes, seg_metas, resampler, sp_tokenizer,
                             correct_refs, wrong_refs, device, args, step):
    """Contrastive (correct vs wrong ref) + reliance (with vs without memory)."""
    correct_lp = _body_logprob(base_lm, codes, seg_metas, resampler, sp_tokenizer,
                               correct_refs, device, args, use_memory=True)

    contrastive = torch.tensor(0.0, device=device)
    if step >= args.contrastive_start_step:
        wrong_lp = _body_logprob(base_lm, codes, seg_metas, resampler, sp_tokenizer,
                                 wrong_refs, device, args, use_memory=True)
        gaps = [correct_lp[b].item() - wrong_lp[b].item() for b in correct_lp if b in wrong_lp]
        if gaps:
            logger.info(f"[contrastive] mean_gap={sum(gaps) / len(gaps):.4f} n={len(gaps)}")
        losses = [F.relu(args.contrastive_margin - (correct_lp[b] - wrong_lp[b]))
                  for b in correct_lp if b in wrong_lp]
        if losses:
            contrastive = torch.stack(losses).mean() * args.contrastive_weight

    reliance = torch.tensor(0.0, device=device)
    if args.reliance_weight > 0 and step >= args.reliance_start_step:
        noref_lp = _body_logprob(base_lm, codes, seg_metas, resampler, sp_tokenizer,
                                 correct_refs, device, args, use_memory=False)
        rl = [F.relu(args.reliance_margin - (correct_lp[b] - noref_lp[b]))
              for b in correct_lp if b in noref_lp]
        if rl:
            reliance = torch.stack(rl).mean() * args.reliance_weight
    return contrastive, reliance


# ---------------------------------------------------------------------------
# Training step
# ---------------------------------------------------------------------------

def training_step(batch, lm, resampler, ref_buffer, args, rng, device, tokenizer, sp_tokenizer,
                  step=0, diag_every=40, do_backward=True):
    codes = batch.codes.to(device)

    last_frame_text = codes[:, 0, -1]
    bad_last = (last_frame_text >= lm.text_card + 1) | ((last_frame_text < 0) & (last_frame_text != lm.zero_token_id))
    if bad_last.any():
        bad_batch_idxs = bad_last.nonzero(as_tuple=True)[0].tolist()
        bad_vals = last_frame_text[bad_last].tolist()
        raise ValueError(f"[step {step}] codes[:,0,-1] out-of-range at batch idx {bad_batch_idxs}: {bad_vals}")

    seg_metas = batch.segment_metas
    base_lm = lm
    pad_id = lm.text_padding_token_id

    ref_texts = [batch.reference_texts[m.batch_idx] if m is not None else "" for m in seg_metas]
    ref_buffer.add([t for t in ref_texts if t])
    wrong_texts = ref_buffer.sample_wrong(ref_texts, seg_metas, rng)

    filtered_metas = [m for m in seg_metas if m is not None]
    ref_latents, ref_slot_mask = build_ref_latents_batch(
        seg_metas, ref_texts, sp_tokenizer, pad_id, resampler, device, args)
    active = build_sticky_active_mask(codes.shape[0], codes.shape[-1], filtered_metas, device)
    # Curriculum: learn the normal (no-memory) pathway first; only then let the
    # sticky memory influence attention. Prevents the untrained adapter from
    # derailing the pretrained model at the start of training.
    if step < args.sticky_warmup_steps:
        active = torch.zeros_like(active)

    if step % diag_every == 0:
        with torch.no_grad():
            n_live = int((ref_slot_mask.sum(dim=-1) > 0).sum().item())
            logger.info(
                f"[sticky] step {step} live={n_live} active_frames={int(active.sum().item())} "
                f"latent_norm={ref_latents.float().norm(dim=-1).mean().item():.4f} "
                f"out_proj_w={resampler.out_proj.weight.float().norm().item():.4f}")

    output = forward_train_sticky(
        base_lm, codes=codes, seg_metas=filtered_metas,
        ref_latents=ref_latents, ref_slot_mask=ref_slot_mask, ref_active=active)

    if step % diag_every == 0:
        log_training_signals(codes, output, filtered_metas, tokenizer, base_lm, step)

    text_loss, audio_loss = compute_rag_losses(
        model=base_lm, output=output, codes=codes, seg_metas=filtered_metas, args=args)

    contrastive_loss = torch.tensor(0.0, device=device)
    reliance_loss = torch.tensor(0.0, device=device)
    if any(wrong_texts) and step >= min(args.contrastive_start_step, args.reliance_start_step):
        contrastive_loss, reliance_loss = compute_grounding_losses(
            base_lm, codes, seg_metas, resampler, sp_tokenizer,
            ref_texts, wrong_texts, device, args, step)

    loss = text_loss + audio_loss + contrastive_loss + reliance_loss
    if do_backward:
        loss.backward()
    base_lm.sticky_kv.clear_training_context()

    return {"loss": loss.item(), "text_loss": text_loss.item(), "audio_loss": audio_loss.item(),
            "contrastive": contrastive_loss.item(), "reliance": reliance_loss.item()}


# ---------------------------------------------------------------------------
# Main training loop
# ---------------------------------------------------------------------------

def train(args: argparse.Namespace) -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    device = torch.device(args.device)

    logger.info("loading tokenizer")
    if args.tokenizer is None:
        args.tokenizer = hf_hub_download(args.hf_repo, loaders.TEXT_TOKENIZER_NAME)
    tokenizer = sentencepiece.SentencePieceProcessor(args.tokenizer)

    logger.info("loading mimi (frozen)")
    if args.mimi_weight is None:
        args.mimi_weight = hf_hub_download(args.hf_repo, loaders.MIMI_NAME)
    mimi = loaders.get_mimi(args.mimi_weight, device)
    mimi.eval()
    for p in mimi.parameters():
        p.requires_grad_(False)

    logger.info("loading moshi LM (bf16)")
    if args.moshi_weight is None:
        args.moshi_weight = hf_hub_download(args.hf_repo, loaders.MOSHI_NAME)
    lm_base: LMModel = loaders.get_moshi_lm(args.moshi_weight, device=device, cpu_offload=False)
    lm_base.eval()
    model_dtype = next(lm_base.parameters()).dtype

    lookup_token_id = lookup_id(tokenizer)
    if lookup_token_id == tokenizer.unk_id():
        raise ValueError("<lookup> is not a piece in the tokenizer vocab — add it before training")
    ref_token_id = ref_id(tokenizer)
    if ref_token_id == tokenizer.unk_id():
        raise ValueError("<ref> is not a piece in the tokenizer vocab — add it before training")

    tokenizer_vocab_size = tokenizer.GetPieceSize()
    required_text_card = max(tokenizer_vocab_size, lookup_token_id + 1, ref_token_id + 1)
    if required_text_card > lm_base.text_card:
        n_new = required_text_card - lm_base.text_card
        logger.info(f"growing text vocab by {n_new}")
        lm_base.grow_text_vocab(n_new=n_new)

    lora_params = apply_lora_to_streaming_attention(
        lm_base, rank=args.lora_rank, alpha=args.lora_rank * args.lora_scaling)

    # Sticky-memory parameters (the learnable per-slot logit bias) are frozen by
    # apply_lora_to_streaming_attention; re-enable them.
    sticky_params = list(lm_base.sticky_kv.parameters())
    for p in sticky_params:
        p.requires_grad_(True)
    lm = lm_base

    # Re-enable the base adapter modules that apply_lora froze. Backbone stays bf16.
    if args.ft_embed:
        for mod in (lm_base.text_emb, lm_base.depformer_text_emb):
            for p in mod.parameters():
                p.requires_grad_(True)
    else:
        logger.info("[opt] text_emb/depformer_text_emb frozen (pass --ft-embed to train them)")
    for mod in (lm_base.text_linear, lm_base.emb, lm_base.linears,
                lm_base.depformer_in, lm_base.depformer_emb):
        for p in mod.parameters():
            p.requires_grad_(True)

    d_model = lm_base.text_emb.embedding_dim
    resampler = RefResampler(
        text_emb=lm_base.text_emb, context_dim=d_model,
        n_ref_slots=args.n_ref_slots, n_layers=args.resampler_layers,
        device=device, dtype=torch.float32,
    )

    # Start the sticky memory with zero content. A zero output projection makes
    # the latents exactly zero, so the pretrained model is not fed random K/V
    # from every layer's attention at step 0 (which collapses the text head to
    # the pad token). The resampler still receives gradients through the key
    # path, so it grows off zero normally. A small softmax dilution remains from
    # the extra (logit-0) slots, which the model absorbs.
    with torch.no_grad():
        resampler.out_proj.weight.zero_()
        resampler.out_proj.bias.zero_()
    logger.info("[sticky] resampler.out_proj zero-initialised (memory starts with zero content)")

    if args.gradient_checkpointing:
        enable_gradient_checkpointing(lm)
    lm.train()
    resampler.train()

    new_text_params = list(lm_base.text_linear.parameters())
    if args.ft_embed:
        new_text_params = (list(lm_base.text_emb.parameters())
                           + list(lm_base.depformer_text_emb.parameters())
                           + new_text_params)
    audio_params = list(lm_base.emb.parameters()) + list(lm_base.linears.parameters())
    depformer_adapt_params = (list(lm_base.depformer_in.parameters())
                              + list(lm_base.depformer_emb.parameters()))
    resampler_params = [p for n, p in resampler.named_parameters()
                        if p.requires_grad and not n.startswith("text_emb.")]

    optimizer = AdamW([
        {"name": "lora", "params": lora_params, "lr": args.lr, "weight_decay": args.weight_decay},
        {"name": "text", "params": new_text_params, "lr": args.lr, "weight_decay": 0.0},
        {"name": "audio", "params": audio_params, "lr": args.lr, "weight_decay": 0.0},
        {"name": "depformer_adapt", "params": depformer_adapt_params,
         "lr": args.lr, "weight_decay": args.weight_decay},
        {"name": "sticky", "params": sticky_params,
         "lr": args.sticky_lr, "weight_decay": 0.0},
        {"name": "resampler", "params": resampler_params,
         "lr": args.resampler_lr, "weight_decay": args.weight_decay},
    ], betas=(0.9, 0.95), eps=1e-8)

    resampler_group = next(g for g in optimizer.param_groups if g["name"] == "resampler")
    scheduler = CosineAnnealingLR(optimizer, T_max=args.max_steps, eta_min=args.lr * 0.1)

    # ── Dataset ───────────────────────────────────────────────────────────
    interleaver = Interleaver(
        tokenizer=tokenizer, audio_frame_rate=mimi.frame_rate,
        text_padding=lm_base.text_padding_token_id,
        end_of_text_padding=lm_base.end_of_text_padding_id,
        zero_padding=lm_base.zero_token_id,
        keep_main_only=True, use_bos_eos=True,
        main_speaker_label="ASSISTANT", device=str(device),
    )
    instruct_tokenizer = InterleavedTokenizer(
        mimi=mimi, interleaver=interleaver, duration_sec=args.duration_sec,
        n_ref_slots=args.n_ref_slots,
        max_ref_source_tokens=args.max_ref_source_tokens,
        target_n_audio_codebooks=16,
        text_card=lm_base.text_card,
        ref_mode="sticky",
    )
    data_dir = Path(args.data_dir)
    if args.eval_data:
        train_manifest, eval_manifest = args.train_data, args.eval_data
    else:
        with open(args.train_data) as f:
            all_lines = [line for line in f if line.strip()]
        train_lines, val_lines = split_train_val(all_lines, val_fraction=args.val_fraction, seed=args.split_seed)
        data_dir.mkdir(parents=True, exist_ok=True)
        train_manifest_path = data_dir / "train_split.jsonl"
        eval_manifest_path = data_dir / "val_split.jsonl"
        train_manifest_path.write_text("".join(train_lines))
        eval_manifest_path.write_text("".join(val_lines))
        train_manifest, eval_manifest = str(train_manifest_path), str(eval_manifest_path)
        logger.info(f"[split] {len(train_lines)} train / {len(val_lines)} val")

    args.train_data = train_manifest
    args.eval_data = eval_manifest

    train_loader = build_data_loader(
        instruct_tokenizer=instruct_tokenizer, args=args, batch_size=args.batch_size,
        seed=42, rank=0, world_size=1, is_eval=False)
    eval_loader = build_data_loader(
        instruct_tokenizer=instruct_tokenizer, args=args, batch_size=args.batch_size,
        seed=0, rank=0, world_size=1, is_eval=True) if args.eval_data else None

    start_step = 0
    if args.resume:
        start_step = load_checkpoint(Path(args.resume), lm, resampler, optimizer, scheduler)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rng = random.Random(42)
    step = start_step
    running = {k: 0.0 for k in ("loss", "text_loss", "audio_loss", "contrastive", "reliance")}
    running_n = 0
    t0 = time.time()
    optimizer.zero_grad()
    accum_steps = 0
    ref_buffer = ReferenceBuffer()

    logger.info(f"starting sticky-kv training from step {step}")

    for batch in train_loader:
        if step >= args.max_steps:
            break

        scalars = training_step(
            batch=batch, lm=lm, resampler=resampler, ref_buffer=ref_buffer,
            args=args, rng=rng, device=device, tokenizer=tokenizer, sp_tokenizer=tokenizer, step=step)
        accum_steps += 1
        for k, v in scalars.items():
            running[k] += v
        running_n += 1

        if accum_steps >= args.grad_accum:
            torch.nn.utils.clip_grad_norm_(
                list(lm.parameters()) + list(resampler.parameters()), max_norm=1.0)
            optimizer.step()
            scheduler.step()
            if step < args.resampler_warmup_steps:
                resampler_group['lr'] = args.resampler_lr * (step + 1) / args.resampler_warmup_steps
            optimizer.zero_grad()
            step += 1
            accum_steps = 0

            if step % args.log_every == 0:
                avg = {k: running[k] / max(running_n, 1) for k in running}
                lr = scheduler.get_last_lr()[0]
                logger.info(
                    f"step {step:5d}/{args.max_steps} loss={avg['loss']:.4f} "
                    f"text={avg['text_loss']:.4f} audio={avg['audio_loss']:.4f} "
                    f"contrastive={avg['contrastive']:.4f} reliance={avg['reliance']:.4f} "
                    f"lr={lr:.2e} elapsed={time.time() - t0:.0f}s")
                running = {k: 0.0 for k in running}
                running_n = 0

            if eval_loader is not None and step % args.eval_every == 0:
                lm.eval()
                resampler.eval()
                eval_losses = {k: 0.0 for k in running}
                eval_n = 0
                with torch.no_grad():
                    for eval_batch in eval_loader:
                        s = training_step(
                            batch=eval_batch, lm=lm, resampler=resampler, ref_buffer=ref_buffer,
                            args=args, rng=rng, device=device, tokenizer=tokenizer,
                            sp_tokenizer=tokenizer, step=step, do_backward=False)
                        for k in eval_losses:
                            eval_losses[k] += s.get(k, 0.0)
                        eval_n += 1
                        if eval_n >= 50:
                            break
                avg_eval = {k: v / max(eval_n, 1) for k, v in eval_losses.items()}
                logger.info(f"[eval] step {step} loss={avg_eval['loss']:.4f} text={avg_eval['text_loss']:.4f} "
                            f"audio={avg_eval['audio_loss']:.4f} contrastive={avg_eval['contrastive']:.4f} "
                            f"reliance={avg_eval['reliance']:.4f}")
                lm.train()
                resampler.train()

            if step % args.save_every == 0:
                save_checkpoint(out_dir, step, lm, resampler, optimizer, scheduler, stats={"step": step})

    save_checkpoint(out_dir, step, lm, resampler, optimizer, scheduler, stats={"step": step, "final": True})
    logger.info(f"training complete at step {step}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)

    ap.add_argument("--train-data", required=True)
    ap.add_argument("--data-dir", default="/workspace/train/temp_data")
    ap.add_argument("--eval-data", default="")
    ap.add_argument("--duration-sec", type=float, default=100.0)
    ap.add_argument("--batch-size", type=int, default=16)

    ap.add_argument("--hf-repo", default=loaders.DEFAULT_REPO)
    ap.add_argument("--moshi-weight", default=None)
    ap.add_argument("--mimi-weight", default=None)
    ap.add_argument("--tokenizer", default=None)
    ap.add_argument("--device", default="cuda")
    ap.add_argument("--val-fraction", type=float, default=0.1)
    ap.add_argument("--split-seed", type=int, default=0)

    ap.add_argument("--lora-rank", type=int, default=64)
    ap.add_argument("--lora-scaling", type=float, default=2.0)
    ap.add_argument("--ft-embed", action="store_true")
    ap.add_argument("--gradient-checkpointing", action="store_true", default=True)

    ap.add_argument("--n-ref-slots", type=int, default=16)
    ap.add_argument("--max-ref-source-tokens", type=int, default=300)
    ap.add_argument("--resampler-lr", type=float, default=2e-5)
    ap.add_argument("--resampler-layers", type=int, default=4)
    ap.add_argument("--resampler-warmup-steps", type=int, default=200)

    ap.add_argument("--lr", type=float, default=2e-6)
    ap.add_argument("--sticky-lr", type=float, default=1e-3,
                    help="LR for the sticky memory's per-slot logit bias (starts "
                         "near -2 and opens as the memory proves useful).")
    ap.add_argument("--weight-decay", type=float, default=0.1)
    ap.add_argument("--max-steps", type=int, default=12000)
    ap.add_argument("--grad-accum", type=int, default=1)

    ap.add_argument("--first-codebook-weight", dest="first_codebook_weight_multiplier",
                    type=float, default=100.0)
    ap.add_argument("--num-agent-codebooks", type=int, default=8)
    ap.add_argument("--text-padding-weight", type=float, default=0.1)
    ap.add_argument("--ref-token-weight", type=float, default=5.0)
    ap.add_argument("--lead-weight", type=float, default=1.0)
    ap.add_argument("--filler-weight", type=float, default=0.5)
    ap.add_argument("--body-weight", type=float, default=4.0)
    ap.add_argument("--no-rag-weight", type=float, default=1.0)
    ap.add_argument("--lookup-loss-weight", type=float, default=8.0)
    ap.add_argument("--contrastive-weight", type=float, default=0.5)
    ap.add_argument("--contrastive-margin", type=float, default=0.3)
    ap.add_argument("--reliance-weight", type=float, default=1.0,
                    help="Force the body to depend on the memory: "
                         "relu(margin - (body_lp_with - body_lp_without)).")
    ap.add_argument("--reliance-margin", type=float, default=0.5)
    ap.add_argument("--reliance-start-step", type=int, default=500)
    ap.add_argument("--contrastive-start-step", type=int, default=500,
                    help="Delay the contrastive term until the base pathway is "
                         "learned; on a random resampler it otherwise injects "
                         "noisy gradients.")
    ap.add_argument("--sticky-warmup-steps", type=int, default=200,
                    help="Steps to keep the sticky memory masked so the model "
                         "first learns the normal (no-memory) pathway.")

    ap.add_argument("--out-dir", default="ckpts/rag_sticky")
    ap.add_argument("--resume", default=None)
    ap.add_argument("--save-every", type=int, default=4000)
    ap.add_argument("--log-every", type=int, default=100)
    ap.add_argument("--eval-every", type=int, default=1000)
    ap.add_argument("--shuffle", action="store_true", default=True)

    args = ap.parse_args()
    args.train_data = args.train_data
    args.eval_data = args.eval_data
    train(args)


if __name__ == "__main__":
    main()
